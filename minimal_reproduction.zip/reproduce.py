"""Portable entry point for the frozen core experiments; no input is overwritten."""
from pathlib import Path
import argparse,csv,json,hashlib,sys,traceback,time,math
ROOT=Path(__file__).resolve().parent
CASES=json.loads((ROOT/'cases.json').read_text(encoding='utf-8'))
def read(p):return json.loads(Path(p).read_text(encoding='utf-8'))
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(p,data):
 p=Path(p);p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(data,indent=2,allow_nan=False),encoding='utf-8')
def rows(p):
 with Path(p).open(encoding='utf-8',newline='') as f:return list(csv.DictReader(f))
def modules():
 sys.path[:0]=[str(ROOT/'simulation'),str(ROOT/'audit')]
 import run_submission_audit as runner
 import enhanced_engine as eng
 return runner,eng
def verify_data(args):
 manifest=read(ROOT/'MANIFEST.json');bad=[]
 for item in manifest['files']:
  p=ROOT/item['path']
  if not p.is_file() or sha(p)!=item['sha256']:bad.append(item['path'])
 if bad:raise AssertionError({'changed_or_missing':bad})
 return dict(status='PASS',files=len(manifest['files']),core_cases=len(CASES),case_input_hashes_verified=True)
def metrics(csvpath,recordspath):
 data=rows(csvpath);records=read(recordspath);n=len(data)
 values={
  'tracking_RMS_m':math.sqrt(sum(float(r['e_m'])**2 for r in data)/n),
  'command_difference_RMS_mps2':math.sqrt(sum(float(r['du_mps2'])**2 for r in data)/n),
  'command_squared_integral_proxy':.1*sum(float(r['u_mps2'])**2 for r in data),
  'total_billed_resource':sum(r['service']['charged_resource'] for r in records)}
 return dict(values=values,samples=len(records),decisions=n,metadata=sum(r['service']['metadata_resource'] for r in records),data_attempts=sum(len(r['service']['attempts']) for r in records),minimum_logged_continuous_gap_bound_m=min(float(r['gap_lower_bound_m']) for r in data))
def analyze(args):
 results=[]
 for c in CASES:
  m=metrics(ROOT/c['trajectory'],ROOT/c['records'])
  for k,v in c['expected'].items():assert abs(m['values'][k]-v)<1e-10,(c['name'],k,v,m['values'][k])
  assert m['samples']==180 and m['decisions']==540
  assert m['metadata']==180 and m['values']['total_billed_resource']==180+m['data_attempts']
  results.append(dict(name=c['name'],**m))
 pairs=[]
 for k in ['A','B','C']:
  a=next(x for x in results if x['name']=='C1_'+k+'_all_links');b=next(x for x in results if x['name']=='C1_'+k+'_active_only')
  pairs.append(dict(profile=k,all_link_bill=a['values']['total_billed_resource'],active_bill=b['values']['total_billed_resource'],resource_saving_percent=100*(a['values']['total_billed_resource']-b['values']['total_billed_resource'])/a['values']['total_billed_resource'],tracking_increase_percent=100*(b['values']['tracking_RMS_m']/a['values']['tracking_RMS_m']-1),command_change_percent=100*(b['values']['command_difference_RMS_mps2']/a['values']['command_difference_RMS_mps2']-1)))
 return dict(status='PASS',method='Recomputed from original trajectory CSVs and event records, not PDF values',cases=results,C1_pairs=pairs)
def check_c2(args):
 import numpy as np
 runner,eng=modules();out=[]
 for c in CASES:
  if not c['name'].startswith('C2_'):continue
  runner.configure(c['profile'],c['period'],c['service_mode'],c['initial_e']);models=runner.models_for(c['period'])
  initial=runner.initial_checks(models,c['initial_e']);outer=runner.product_initial_witness(models,c['initial_e'])
  rec=read(ROOT/c['records']);qps=[runner.QP(m,10) for m in models];minrow=float('inf');minphys=float('inf');tailcount=0
  for k,r in enumerate(rec):
   for i,(m,q,z) in enumerate(zip(models,qps,r['controllers'])):
    x=np.asarray(z['state']);nu=np.asarray(z['executed_vector']);cand=np.asarray(z['shifted_candidate']);rhs,_,_,cent=q.build(x,np.asarray(z['intervals']))
    a=q.slack(rhs,nu);b=q.slack(rhs,cand);assert a.min()>=0 and b.min()>=0
    if k:
     assert np.array_equal(cand,np.r_[rec[k-1]['controllers'][i]['executed_vector'][1:],0.]);assert x[3]==rec[k-1]['controllers'][i]['actual_command'];tailcount+=1
    u=float(m['K']@x+m['L']*cent[0]+nu[0]);assert abs(u-z['actual_command'])<1e-12
    physical=m['g']-m['H']@x-m['G']*u;assert physical.min()>=0
    assert z['continuous_gap_certified_lower_bound']>=10
    minrow=min(minrow,float(a.min()),float(b.min()));minphys=min(minphys,float(physical.min()))
  assert tailcount==537
  out.append(dict(name=c['name'],initial=initial,product_current_initial_witness=outer,decisions=540,post_initial_candidates=tailcount,minimum_condensed_row_slack=minrow,minimum_actual_sampled_row_slack=minphys))
 return dict(status='PASS',scope='Rebuilt initial conditional/product-current programs and all recorded executed/shifted rows; stored continuous-gap bound checked, not a new independent analytic gap proof',cases=out)
def simulate(args):
 runner,eng=modules();selected=CASES if args.case=='all' else [next(c for c in CASES if c['name']==args.case)];results=[]
 for c in selected:
  target=args.output/'fresh_runs'/c['name'];target.mkdir(parents=True,exist_ok=True)
  save(target/'configuration.json',c)
  try:
   runner.configure(c['profile'],c['period'],c['service_mode'],c['initial_e']);models=runner.models_for(c['period']);eng.HERE=target
   initial=runner.initial_checks(models,c['initial_e']);save(target/'initialization.json',initial)
   if c['name'].startswith('C2_'):save(target/'product_current_initial_witness.json',runner.product_initial_witness(models,c['initial_e']))
   summary=eng.run_case(models,c['horizon'],'reserved','qp',c['seconds']);folder=target/'results'/summary['name']
   recalculated=metrics(folder/'trajectory.csv',folder/'step_records.json');differences={k:recalculated['values'][k]-v for k,v in c['expected'].items()}
   assert all(abs(v)<=1e-8 for v in differences.values()),differences
   assert recalculated['values']['total_billed_resource']==c['expected']['total_billed_resource']
   result=dict(name=c['name'],status='PASS',metric_differences=differences,results=recalculated,scope='Fresh full180-sample simulation with unchanged physical/controller logic; wall times not required to match')
   save(target/'comparison.json',result);results.append(result)
  except Exception as exc:
   save(target/'failure.json',dict(status='FAILED',case=c,error=repr(exc),traceback=traceback.format_exc()));raise
 return dict(status='PASS',fresh_cases=results)
def certificate(args):
 modules()
 import numpy as np
 from run_enhancements import models_for
 from verify_shared_terminal import independently_verify_stored
 models=models_for(args.period);design=read(ROOT/'simulation/period_models'/f'P{args.period}'/'design.json');results=[]
 for i,(m,v) in enumerate(zip(models,design['vehicles']),1):
  r=independently_verify_stored(m,v['tau'],v['K_roundtrip'],str(v['operating_speed_previous']),str(v['operating_speed_own']),str(m['delta']))
  results.append(dict(vehicle=i,**r))
 return dict(status='PASS',period=args.period,checks=results,scope='Fresh optional directed certificate verification only; no redesign')
def main():
 p=argparse.ArgumentParser();p.add_argument('command',choices=['verify-data','analyze','check-c2','simulate','certificate']);p.add_argument('--case',choices=['all']+[c['name'] for c in CASES],default='C1_A_all_links');p.add_argument('--period',type=int,choices=[2,3,4,5],default=3);p.add_argument('--output',type=Path,default=ROOT/'outputs');args=p.parse_args();args.output=args.output.resolve();args.output.mkdir(parents=True,exist_ok=True)
 started=time.perf_counter()
 try:
  result=globals()[args.command.replace('-','_')](args);result['elapsed_seconds']=time.perf_counter()-started;save(args.output/(args.command+'.json'),result);print(json.dumps(result,indent=2))
 except Exception as exc:
  save(args.output/(args.command+'_failure.json'),dict(status='FAILED',error=repr(exc),traceback=traceback.format_exc()));raise
if __name__=='__main__':main()
