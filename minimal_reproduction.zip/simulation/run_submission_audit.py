"""Three prespecified admissible maneuvers, paired service, one second C2 state.
No previous experiment is re-executed. No weight/gain/envelope tuning.
"""
from pathlib import Path
import sys,tempfile,json,traceback,hashlib
ROOT=Path(__file__).resolve().parents[1];SIM=ROOT/'simulation'
sys.path.insert(0,str(SIM))
import numpy as np
from scipy.optimize import linprog
import enhanced_engine as eng
from run_enhancements import models_for
from run_final_revision import ActiveOnlyNetwork,initial_checks,complete_records,product_initial_witness,QP,BASE
from audit_scenarios import SCENARIOS,values,verify_declared_profiles
def dump(p,o):p.write_text(json.dumps(o,indent=2,ensure_ascii=False,allow_nan=False),encoding='utf-8')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
class WorstNetwork(BASE):
    """Every other reservation fails; every primary success available k+1."""
    def attempt(self,k,i,speed,kind):
        assert kind=='reserved';idx=int(self.reserved_indices[i]);self.reserved_indices[i]+=1
        failed=idx%2==1;self.sent[i][k]=float(speed)
        if not failed:
            self.queue.append(dict(link=i,generation=k,speed=float(speed),available=k+1,duplicate=False,kind=kind,late_phase=False))
        return dict(link=i+1,kind=kind,generation=k,fresh_speed=float(speed),potential_index=idx,failed=bool(failed),
            delay_samples=None if failed else 1,charged_data_units=1,
            raw_snapshot_interval_at_generation=eng.snapshot_interval(self.models[i],k,0,k,speed).tolist())
class WorstActiveNetwork(ActiveOnlyNetwork):
    attempt=WorstNetwork.attempt
def configure(name,P,mode,e=0.):
    eng.PERIOD=P;eng.PHASES=np.array([0,0,1]);eng.INITIAL_E=e;eng.SCENARIO='mild';eng.RANDOM_SEED=20261014;eng.CondensedQP=QP
    worst=name!='original_mild' and SCENARIOS[name]['service']=='worst'
    eng.Network=(WorstActiveNetwork if mode=='active_only' else WorstNetwork) if worst else (ActiveOnlyNetwork if mode=='active_only' else BASE)
    eng.leader_speed=lambda t:values(name,t)[0]
    eng.leader_accel=lambda t:values(name,t)[1]
    eng.leader_relative_position=lambda t:values(name,t)[2]
def history_domain():
    configure('original_mild',5,'all_links');models=models_for(5);points=[]
    # Fixed physical-history family |e1|<=2.8, not LP-endpoint interpolation.
    for e in [-2.8,2.8]:
        checks=initial_checks(models,e);points.append(dict(e1=e,vehicles=checks))
    result=dict(definition='All t<0: v_i=25, a_i=u_previous=omega_i=0; gaps d1=35+e1 with |e1|<=2.8 m, d2=d3=35; snapshots generations[-5,-5,-4] with speed0, availability generation+1.',
        endpoint_checks=points,convexity_argument='At fixed valid cache the condensed inequalities are affine in state and corrections. Interpolating the two feasible full vectors certifies every e1 in the interval for follower1; other initial local problems stay zero. Every member has the stated constant-speed physical history.',
        chosen_second_state_e1=-2.5,selection='Fixed 2.5m shortfall from desired gap, inside the independently specified and endpoint-checked history family. No search over outcomes, weights or cache values.',
        bootstrap='Initial successful reservation index0 at phases-P, processed generation+1; subsequent index starts1, continuing phases.',scope='Numerically verified feasible witnesses with positive reserve, not a formal proof of all machine arithmetic.')
    dump(ROOT/'audit/second_C2_history_domain.json',result);return result
def main():
    assert json.loads((ROOT/'audit/certificate_reproduction.json').read_text())['all_passed']
    profile_cert=verify_declared_profiles();dump(ROOT/'audit/leader_domain_certificate.json',profile_cert)
    domain=history_domain();specs=[(name,mode,c['P'],0.) for name,c in SCENARIOS.items() for mode in ['all_links','active_only']]
    specs.append(('original_mild','all_links',5,-2.5))
    dump(ROOT/'audit/experiment_prespecification.json',dict(scenarios=SCENARIOS,domain_certificate=profile_cert,specifications=specs,
        common=dict(horizon=10,seconds=18,seed=20261014,metadata_frame_units=1,bootstrap_excluded=True,follower_disturbance='.2*sin(.4*k*.1+[.3,1.1,2])',
            original_weights_and_gains=True,original_period_terminal_matrices=True),no_outcome_search=True))
    results=[]
    for profile,mode,P,e in specs:
        label=f'C1_{profile}_{mode}' if e==0 else 'C2_second_physical_history'
        configure(profile,P,mode,e);models=models_for(P);eng.HERE=SIM/'audit_results'/label;eng.HERE.mkdir(parents=True,exist_ok=True)
        cfg=dict(name=label,profile=profile,P=P,service_mode=mode,external_service='alternating failures and all successful primary delays1' if 'worst' in profile else 'unchanged source fixed pattern',
            initial_e=e,initial_generations=[int(p)-P for p in eng.PHASES],initial_snapshot_speeds=[0.,0.,0.],seconds=18,horizon=10,seed=20261014,
            delta=[m['delta'] for m in models],beta=[m['beta'] for m in models],metadata_per_sample=1,initial_physical_history='v25, a=u_previous=omega=0 for all negative time, gaps35+e1,35,35; no state reset at controller takeover',
            model_sha256=[m['sha256'] for m in models],engine_sha256=sha(SIM/'enhanced_engine.py'),wrapper_sha256=sha(Path(__file__)),profile_source_sha256=sha(SIM/'audit_scenarios.py'))
        dump(eng.HERE/'configuration.json',cfg)
        try:
            ini=initial_checks(models,e);dump(eng.HERE/'initialization.json',ini)
            if e:
                witness=product_initial_witness(models,e);witness['inequality_direction']='nu0 >= bound (negative command-rate row)'
                dump(eng.HERE/'product_initial_infeasibility.json',witness)
            result=eng.run_case(models,10,'reserved','qp',18.)
            # Generic source engine labels are overridden to the actual supplied profile.
            result['leader_speed_formula']='1.2*sin(.35*t)^3' if profile=='original_mild' else SCENARIOS[profile]['description']
            result['scenario']=profile
            folder=eng.HERE/'results'/result['name'];dump(folder/'summary.json',result)
            audit=complete_records(folder,models)
            result.update(group=label,status='COMPLETED',configuration=cfg,audit=audit)
            dump(folder/'summary.json',result);results.append(result)
        except Exception as exc:
            failure=dict(group=label,status='FAILED',error=repr(exc),traceback=traceback.format_exc(),configuration=cfg)
            tb=exc.__traceback__
            while tb:
                loc=tb.tb_frame.f_locals
                if tb.tb_frame.f_code.co_name=='run_case':
                    dump(eng.HERE/'partial_step_records.json',loc.get('records',[]));failure['failed_sample']=loc.get('k')
                    if 'states' in loc:failure['states']=loc['states'].tolist()
                tb=tb.tb_next
            dump(eng.HERE/'failure.json',failure);results.append(failure)
        dump(SIM/'submission_audit_summary.json',dict(cases=results,all_completed=len(results)==len(specs) and all(c['status']=='COMPLETED' for c in results)))
        print(json.dumps({k:results[-1].get(k) for k in ['group','status','tracking_RMS_m','tracking_max_abs_m','total_billed_resource','error']}),flush=True)
    assert all(c['status']=='COMPLETED' for c in results)
if __name__=='__main__':main()
