"""Causal robust-QP validation for the certified finite terminal preimage set.

--initialize-only executes static LP/QP witnesses and never advances a plant.
--run is blocked until the parent directory has an explicit FROZEN/FEASIBLE
validation_gate.json. Every stored trajectory is an actual calculation.
"""
from pathlib import Path
import argparse, csv, hashlib, json, math, sys, tempfile, time
import numpy as np
import scipy
from scipy import sparse
from scipy.optimize import linprog
import osqp

ROOT=Path(__file__).resolve().parents[1]
HERE=Path(__file__).resolve().parent
SCENARIO='mild'; INITIAL_E=0.; RANDOM_SEED=20261014;
T=.1; NVEH=3; U=1.8; DU=.3; SIGMA=.2; OMEGA=.2
DISTURBANCE_PHASES=np.array([.3,1.1,2.])
VREF=25.; D0=5.; ELL=4.5; DSAFE=10.; A=2.
CONTRACT=np.array([1.5,1.85,2.25,2.7])
PHASES=np.array([0,0,1]); M=2; PERIOD=2; BF=1; DELAY=1
THETA=1e-9; NUMERIC_GUARD=1e-7; VERIFY_TOL=0.

def write_json(path,data):
    path.write_text(json.dumps(data,indent=2,ensure_ascii=False,allow_nan=False),encoding='utf-8')

def load_models():
    models=[]
    for i in range(1,NVEH+1):
        path=HERE/f'vehicle_{i}.npz'
        if not path.exists(): raise FileNotFoundError(f'Certified model missing: {path}')
        with np.load(path,allow_pickle=False) as zz:
            model={name:np.array(zz[name],copy=True) for name in zz.files}
        for name in ['A','B','E','F','K','L','W_halfwidth','S','H','G','g','Hf','hf','Q','Pf','tau','h','beta','delta','Si']:
            if name not in model: raise KeyError(f'{path.name} lacks {name}')
        for name in ['L','tau','h','beta','delta','Si']:
            model[name]=float(np.asarray(model[name]).reshape(-1)[0])
        for name in ['B','E','K','G','g','hf','W_halfwidth']:
            model[name]=np.asarray(model[name],float).ravel()
        assert model['delta']>=0 and abs(model['L']-.25)<1e-12
        assert abs(model['Si']-CONTRACT[i])<1e-12
        assert abs(model['beta']-T*CONTRACT[i-1])<1e-12
        assert model['Hf'].shape[0]==model['hf'].size and model['Hf'].shape[1]==4
        assert np.max(np.abs(model['F']-(model['A']+np.outer(model['B'],model['K']))))<1e-12
        model['path']=path.name
        model['sha256']=hashlib.sha256(path.read_bytes()).hexdigest()
        model['r_u']=float(np.asarray(model.get('r_u',1/U**2)))
        model['r_nu']=float(np.asarray(model.get('r_nu',1/SIGMA**2)))
        models.append(model)
    return models

class CondensedQP:
    """Full physical and terminal rows; current graph / future product supports."""
    def __init__(self,model,horizon):
        self.m=model; self.N=horizon; self.solver=None
        F,B,K,H,G=model['F'],model['B'],model['K'],model['H'],model['G']
        self.fp=[np.linalg.matrix_power(F,j) for j in range(horizon+1)]
        self.v=[np.zeros((4,horizon))]
        for j in range(horizon):
            nxt=F@self.v[-1]; nxt[:,j]+=B; self.v.append(nxt)
        self.uv=[]; condensed=[]
        for j in range(horizon):
            uj=K@self.v[j]; uj[j]+=1.; self.uv.append(uj)
            condensed.append(H@self.v[j]+G[:,None]*uj[None,:])
        condensed.append(model['Hf']@self.v[horizon])
        self.C=np.vstack(condensed)
        self.nr=len(G); self.nphysical=self.nr*horizon
        self.zeta=H+G[:,None]*K[None,:]
        Hess=2*model['r_nu']*np.eye(horizon)
        for j in range(horizon):
            Hess+=2*(self.v[j].T@model['Q']@self.v[j]+model['r_u']*np.outer(self.uv[j],self.uv[j]))
        Hess+=2*self.v[horizon].T@model['Pf']@self.v[horizon]
        self.Hess=.5*(Hess+Hess.T)
        self.solver_C=sparse.csc_matrix(np.vstack([self.C,np.eye(horizon)]))
        # Tube supports are affine functions of installed radii. Cache all
        # finite support directions, including every terminal preimage face.
        self.tube_cache={}
        for j in range(horizon): self.tube_cache[('physical',j)]=self.prepare_support(self.zeta,j)
        self.tube_cache[('terminal',horizon)]=self.prepare_support(model['Hf'],horizon)

    def prepare_support(self,rows,j):
        d=self.m['E']+self.m['B']*self.m['L']; bl=self.m['B']*self.m['L']
        radii=np.zeros((len(rows),self.N)); base=np.zeros(len(rows))
        for t in range(j):
            rr=rows@self.fp[j-1-t]
            if t==0: radii[:,t]=np.abs(rr@self.m['E'])
            else:
                radii[:,t]=np.abs(rr@d)
                base+=self.m['delta']*np.abs(rr@bl)
            base+=np.abs(rr)@self.m['W_halfwidth']
        return radii,base

    def build(self,x,intervals):
        centers=intervals.mean(axis=1); radii=(intervals[:,1]-intervals[:,0])/2
        assert len(centers)==self.N and np.min(radii)>=-1e-12
        assert radii[0]<=self.m['delta']+1e-10
        z=[np.asarray(x,float).copy()]; d=self.m['E']+self.m['B']*self.m['L']
        for j in range(self.N): z.append(self.m['F']@z[-1]+d*centers[j])
        rhs=[]; linear=np.zeros(self.N)
        for j in range(self.N):
            uc=self.m['K']@z[j]+self.m['L']*centers[j]
            coeff,base=self.tube_cache[('physical',j)]
            support=coeff@radii+base
            # At j=0, q_b+q_epsilon cancels exactly: the input estimate is known.
            if j>=1: support+=np.abs(self.m['G']*self.m['L'])*(radii[j]+self.m['delta'])
            rhs.append(self.m['g']-self.m['H']@z[j]-self.m['G']*uc-support)
            linear+=2*(self.v[j].T@self.m['Q']@z[j]+self.m['r_u']*self.uv[j]*uc)
        coeff,base=self.tube_cache[('terminal',self.N)]
        rhs.append(self.m['hf']-self.m['Hf']@z[self.N]-coeff@radii-base)
        linear+=2*self.v[self.N].T@self.m['Pf']@z[self.N]
        return np.concatenate(rhs),linear,z,centers

    def slack(self,rhs,nu): return rhs-self.C@nu

    def objective(self,z,centers,nu):
        total=0.
        for j in range(self.N):
            zj=z[j]+self.v[j]@nu
            uj=float(self.m['K']@zj+self.m['L']*centers[j]+nu[j])
            total+=float(zj@self.m['Q']@zj+self.m['r_u']*uj*uj+self.m['r_nu']*nu[j]*nu[j])
        zn=z[self.N]+self.v[self.N]@nu
        return total+float(zn@self.m['Pf']@zn)

    def solve(self,rhs,linear,warm=None):
        # A small explicit conservative row reserve prevents solver feasibility
        # tolerance from being interpreted as permission to violate a true row.
        upper=np.r_[rhs-NUMERIC_GUARD,np.full(self.N,SIGMA-NUMERIC_GUARD)]
        lower=np.r_[np.full(len(rhs),-np.inf),np.full(self.N,-SIGMA+NUMERIC_GUARD)]
        if self.solver is None:
            self.solver=osqp.OSQP()
            self.solver.setup(P=sparse.csc_matrix(np.triu(self.Hess)),q=linear,A=self.solver_C,
                              l=lower,u=upper,verbose=False,eps_abs=1e-9,eps_rel=1e-9,
                              max_iter=30000,polishing=True)
        else: self.solver.update(q=linear,l=lower,u=upper)
        if warm is not None: self.solver.warm_start(x=warm)
        result=self.solver.solve(raise_error=False)
        nu=None if result.x is None else np.array(result.x)
        good=(nu is not None and result.info.status_val in [1,2] and
              np.max(np.abs(nu))<=SIGMA+VERIFY_TOL and self.slack(rhs,nu).min()>=-VERIFY_TOL)
        return (nu if good else None),{'status':result.info.status,'iterations':int(result.info.iter),
                                      'primal_residual':float(result.info.prim_res),'dual_residual':float(result.info.dual_res)}

def snapshot_interval(model,k,j,generation,speed):
    rho=A*T*T*(k+j-generation+.5)
    return np.array([max(-model['beta'],T*speed-rho),min(model['beta'],T*speed+rho)])

def initial_cache(model,i,N):
    generation=int(PHASES[i])-PERIOD
    return np.array([snapshot_interval(model,0,j,generation,0.) for j in range(N)])

def initialize_only(models):
    allchecks=[]
    for N in [1,2,10]:
        for i,model in enumerate(models):
            qp=CondensedQP(model,N); cache=initial_cache(model,i,N)
            rhs,linear,z,centers=qp.build(np.zeros(4),cache)
            zero=np.zeros(N); zero_slack=qp.slack(rhs,zero)
            lp=linprog(np.zeros(N),A_ub=qp.C,b_ub=rhs-NUMERIC_GUARD,
                       bounds=[(-SIGMA,SIGMA)]*N,method='highs')
            optimum,status=qp.solve(rhs,linear,zero)
            record={'follower':i+1,'N':N,'generation':-2 if PHASES[i]==0 else -1,
                    'initial_state':[0.]*4,'initial_cache':cache.tolist(),
                    'all_zero_witness_valid':bool(zero_slack.min()>=0),
                    'physical_min_zero_slack':float(zero_slack[:qp.nphysical].min()),
                    'terminal_min_zero_slack':float(zero_slack[qp.nphysical:].min()),
                    'full_terminal_faces':len(model['hf']),'physical_rows':qp.nr,
                    'LP_success':bool(lp.success),'LP_status':lp.message,
                    'LP_witness':None if not lp.success else lp.x.tolist(),
                    'QP_status':status,'QP_correction':None if optimum is None else optimum.tolist(),
                    'J_zero':qp.objective(z,centers,zero),
                    'J_optimal':None if optimum is None else qp.objective(z,centers,optimum)}
            assert record['all_zero_witness_valid'] and lp.success and optimum is not None
            allchecks.append(record)
    result={'scope':'Static initialized LP/QP checks only; no plant steps or closed-loop performance simulation',
            'models':{m['path']:m['sha256'] for m in models},'checks':allchecks,
            'all_initializations_passed':True,'simulation_executed':False,
            'numeric_versions':{'numpy':np.__version__,'scipy':scipy.__version__,'osqp':osqp.__version__}}
    write_json(HERE/'initialization_results.json',result)
    print(json.dumps({'all_initializations_passed':True,'checks':len(allchecks),'simulation_executed':False},indent=2))

def frequency(): return .35 if SCENARIO=='mild' else 1.35
def leader_speed(t): return 0. if t<0 else 1.2*math.sin(frequency()*t)**3
def leader_accel(t): return 0. if t<0 else 3*1.2*frequency()*math.sin(frequency()*t)**2*math.cos(frequency()*t)
def leader_relative_position(t):
    if t<0: return 0.
    co=math.cos(frequency()*t)
    return 1.2/frequency()*(2/3-co+co**3/3)

class Network:
    def __init__(self,models,N,selector,seed):
        self.models=models; self.N=N; self.selector=selector; self.rng=np.random.default_rng(seed)
        self.latest=np.array([int(p)-PERIOD for p in PHASES]); self.snapshot=np.zeros(NVEH)
        self.ack=self.latest.copy(); self.ack_speed=np.zeros(NVEH)
        self.sent=[{int(self.latest[i]):0.} for i in range(NVEH)]
        self.cache=[initial_cache(m,i,N) for i,m in enumerate(models)]
        self.queue=[]; self.reserved_indices=np.ones(NVEH,dtype=int)

    def process(self,k,phase):
        events=[]; newly=[[] for _ in range(NVEH)]; remaining=[]
        batch=[]
        for pkt in self.queue:
            if pkt['available']>k or (phase=='early' and pkt['late_phase']):
                remaining.append(pkt); continue
            batch.append(pkt)
        if phase=='accept':
            # Late arrivals and current zero-delay packets share the processing
            # phase; newer generation may be processed first. All primary
            # packets are available within their unchanged D<=1 service bound.
            batch.sort(key=lambda p:(-p['generation'],p['duplicate']))
        for pkt in batch:
            i=pkt['link']; accept=pkt['generation']>self.latest[i]
            reason=None if accept else ('duplicate_generation' if pkt['duplicate'] else 'nonduplicate_out_of_order_generation')
            events.append({**pkt,'processing_phase':phase,'processed_sample':k,'accepted':bool(accept),
                           'discard_reason':reason,'accepted_generation_before_processing':int(self.latest[i])})
            if accept:
                self.latest[i]=pkt['generation']; self.snapshot[i]=pkt['speed']; newly[i].append(pkt)
        self.queue=remaining
        return newly,events

    def attempt(self,k,i,speed,kind):
        if kind=='reserved':
            idx=int(self.reserved_indices[i]); self.reserved_indices[i]+=1
        else:
            # Fixed external potential service indexed by absolute sample/link,
            # independent of how another selector allocated earlier optional slots.
            idx=k+i
        failed=idx%4==1; delay=(idx+i+1)%2
        self.sent[i][k]=float(speed)
        if not failed:
            packet={'link':i,'generation':k,'speed':float(speed),'available':k+delay,'duplicate':False,'kind':kind,
                    'late_phase':bool(delay==0 or (k+i)%3==0)}
            self.queue.append(packet)
            # Receiver/queue duplication of a paid packet, never a new radio grant.
            if (k+i)%11==0: self.queue.append({**packet,'available':k+delay+1,'duplicate':True})
        return {'link':i+1,'kind':kind,'generation':k,'fresh_speed':float(speed),'potential_index':idx,
                'failed':bool(failed),'delay_samples':delay if not failed else None,'charged_data_units':1,
                'raw_snapshot_interval_at_generation':snapshot_interval(self.models[i],k,0,k,speed).tolist()}

    def sample(self,k,speeds):
        prior_latest=self.latest.copy(); prior_snapshot=self.snapshot.copy()
        new,events=self.process(k,'early')
        # Requests are formed before the paid metadata exchange. An ACK carried
        # in this frame is usable for the next sample's request, never earlier.
        score_ack=self.ack.copy(); score_ack_speed=self.ack_speed.copy()
        scores=np.array([self.models[i]['r_u']*self.models[i]['L']**2*T*T*(speeds[i]-score_ack_speed[i])**2 for i in range(NVEH)])
        requests=scores>THETA
        # Paid metadata reports previously accepted timestamps; ACK loss changes
        # optional rankings only and never suppresses a scheduled reservation.
        ack_events=[]
        for i in range(NVEH):
            lost=(k+i)%7==3
            if not lost and self.latest[i]>=self.ack[i]:
                self.ack[i]=self.latest[i]; self.ack_speed[i]=self.sent[i][int(self.latest[i])]
            ack_events.append({'link':i+1,'lost':lost,'visible_generation':int(self.ack[i])})
        reserved=[i for i in range(NVEH) if k%PERIOD==PHASES[i]]
        residual=M-len(reserved); eligible=[i for i in range(NVEH) if requests[i] and i not in reserved]
        if self.selector=='reserved': selected=[]
        elif self.selector=='proposed': selected=sorted(eligible,key=lambda i:(-scores[i],i))[:residual]
        elif self.selector=='aoi': selected=sorted(eligible,key=lambda i:(-(k-score_ack[i]),i))[:residual]
        elif self.selector=='random': selected=list(self.rng.permutation(eligible)[:residual])
        else: raise ValueError(self.selector)
        attempts=[self.attempt(k,i,speeds[i],'reserved') for i in reserved]
        attempts += [self.attempt(k,int(i),speeds[i],'optional') for i in selected]
        znew,zevents=self.process(k,'accept'); events+=zevents
        for i in range(NVEH): new[i]+=znew[i]
        previous=[c.copy() for c in self.cache]
        refinement=[]
        for i,m in enumerate(self.models):
            if k==0: now=self.cache[i].copy()
            else: now=np.vstack([self.cache[i][1:],[-m['beta'],m['beta']]])
            prior_only=now.copy()
            for j in range(self.N):
                old=snapshot_interval(m,k,j,int(prior_latest[i]),float(prior_snapshot[i]))
                prior_only[j,0]=max(prior_only[j,0],old[0]); prior_only[j,1]=min(prior_only[j,1],old[1])
            valid_packets=new[i]+[{'generation':int(self.latest[i]),'speed':float(self.snapshot[i])}]
            for pkt in valid_packets:
                for j in range(self.N):
                    snap=snapshot_interval(m,k,j,pkt['generation'],pkt['speed'])
                    now[j,0]=max(now[j,0],snap[0]); now[j,1]=min(now[j,1],snap[1])
            assert np.all(now[:,0]<=now[:,1]+1e-12)
            assert (now[0,1]-now[0,0])/2<=m['delta']+1e-10
            assert k-self.latest[i]<=(BF+1)*PERIOD+DELAY
            if k>0 and self.N>1:
                assert np.all(now[:-1,0]>=previous[i][1:,0]-1e-12)
                assert np.all(now[:-1,1]<=previous[i][1:,1]+1e-12)
            self.cache[i]=now
            refinement.append({'link':i+1,'accepted_new_generations':[p['generation'] for p in new[i]],
                               'radius_without_new_packet':float((prior_only[0,1]-prior_only[0,0])/2),
                               'radius_after_all_accepted_packets':float((now[0,1]-now[0,0])/2),
                               'actual_radius_reduction':float(((prior_only[0,1]-prior_only[0,0])-(now[0,1]-now[0,0]))/2),
                               'strict_interval_contraction':bool(now[0,1]-now[0,0]<prior_only[0,1]-prior_only[0,0]-1e-10)})
        return {'requests':requests.tolist(),'scores':scores.tolist(),'eligible':[i+1 for i in eligible],
                'reserved':[i+1 for i in reserved],'selected_optional':[int(i)+1 for i in selected],
                'attempts':attempts,'arrivals':events,'ack_events':ack_events,
                'allocated':len(attempts),'charged_resource':1+len(attempts),
                'metadata_resource':1,'capacity_resource':3,'accepted_generation':self.latest.tolist(),
                'accepted_ages':(k-self.latest).tolist(),'visible_ack_generation':self.ack.tolist(),
                'score_ack_generation':score_ack.tolist(),'score_ack_speed_mps':score_ack_speed.tolist(),
                'cache_before_shift':[c.tolist() for c in previous],'refinement':refinement}

def kernels(theta,tau):
    alpha=math.exp(-theta/tau); c=tau*(1-alpha); bu=theta-c; q=tau*bu; r=theta*theta/2-q
    return alpha,c,bu,q,r

def positions_inside(k,theta,positions,states,commands,disturbance,models):
    t=k*T+theta
    out=np.empty(NVEH+1); out[0]=VREF*t+leader_relative_position(t)
    for i,m in enumerate(models):
        _,c,bu,q,r=kernels(theta,m['tau'])
        out[i+1]=positions[i+1]+VREF*theta+theta*states[i,1]+q*states[i,2]+r*commands[i]+m['tau']*r*disturbance[i]
    return out

def run_case(models,N,selector,controller,seconds):
    begin=time.perf_counter(); steps=int(round(seconds/T))
    if abs(steps*T-seconds)>1e-10: raise ValueError('Duration must be an integer number of samples')
    name=f'N{N}_{controller}_{selector}'
    outdir=HERE/'results'/name; outdir.mkdir(parents=True,exist_ok=True)
    preparation_started=time.perf_counter()
    qps=[CondensedQP(m,N) for m in models]; network=Network(models,N,selector,RANDOM_SEED)
    states=np.zeros((NVEH,4)); states[0,0]=INITIAL_E
    positions=np.zeros(NVEH+1)
    for ii in range(NVEH): positions[ii+1]=positions[ii]-ELL-D0-models[ii]['h']*VREF-states[ii,0]
    prepared_initial_vectors=[]
    for i,qp in enumerate(qps):
        rr,ll,_,_=qp.build(states[i],network.cache[i]); witness=np.zeros(N)
        if controller!='zero':
            if qp.slack(rr,witness).min()<NUMERIC_GUARD:
                lp=linprog(np.zeros(N),A_ub=qp.C,b_ub=rr-NUMERIC_GUARD,
                           bounds=[(-SIGMA+NUMERIC_GUARD,SIGMA-NUMERIC_GUARD)]*N,method='highs')
                assert lp.success;witness=lp.x.copy()
            optimum,_=qp.solve(rr,ll,witness);assert optimum is not None;witness=optimum
        assert qp.slack(rr,witness).min()>=0
        prepared_initial_vectors.append(witness.copy())
    preparation_ms=1000*(time.perf_counter()-preparation_started)
    previous_vectors=None; records=[]; optrows=[]; candrows=[]; physicalrows=[]; init=[c.copy() for c in network.cache]
    truth=[]; csvrows=[]
    for k in range(steps):
        pred_speeds=np.r_[leader_speed(k*T),states[:,1]][:NVEH]
        service=network.sample(k,pred_speeds)
        assert service['charged_resource']<=3
        vectors=[]; commands=[]; solved=[]; all_slacks=[]; candidate_slacks=[]
        for i,(model,qp) in enumerate(zip(models,qps)):
            decision_started=time.perf_counter()
            assembly_started=decision_started
            rhs,linear,z,centers=qp.build(states[i],network.cache[i])
            assembly_ms=1000*(time.perf_counter()-assembly_started)
            old=None if previous_vectors is None else previous_vectors[i]
            if old is None:
                candidate=prepared_initial_vectors[i].copy()
                if qp.slack(rhs,candidate).min()<0 and controller!='zero':
                    initial_lp=linprog(np.zeros(N),A_ub=qp.C,b_ub=rhs-NUMERIC_GUARD,
                                       bounds=[(-SIGMA+NUMERIC_GUARD,SIGMA-NUMERIC_GUARD)]*N,method='highs')
                    assert initial_lp.success, f'{name} initial QP has no verified witness, vehicle={i+1}'
                    candidate=initial_lp.x.copy()
            else:
                candidate=np.r_[old[1:],0.]
            shifted=qp.slack(rhs,candidate)
            assert shifted.min()>=-VERIFY_TOL, f'{name} shifted candidate infeasible k={k}, vehicle={i+1}, min={shifted.min()}'
            solve_started=time.perf_counter()
            if controller=='zero':
                nu=np.zeros(N); solver={'status':'fixed_zero_correction','iterations':0,'primal_residual':0.,'dual_residual':0.}
                assert qp.slack(rhs,nu).min()>=-VERIFY_TOL, f'{name} zero-policy outside common feasible domain'
                fallback=False
            else:
                nu,solver=qp.solve(rhs,linear,candidate); fallback=nu is None
                if fallback: nu=candidate.copy()
            solve_ms=1000*(time.perf_counter()-solve_started)
            slack=qp.slack(rhs,nu)
            assert slack.min()>=-VERIFY_TOL and np.max(abs(nu))<=SIGMA+VERIFY_TOL
            command=float(model['K']@states[i]+model['L']*centers[0]+nu[0])
            actual_slack=model['g']-model['H']@states[i]-model['G']*command
            assert actual_slack.min()>=-VERIFY_TOL
            zero_feasible=bool(qp.slack(rhs,np.zeros(N)).min()>=-VERIFY_TOL)
            zero_feasible_guarded=bool(qp.slack(rhs,np.zeros(N)).min()>=NUMERIC_GUARD)
            jzero=qp.objective(z,centers,np.zeros(N)) if zero_feasible else None
            jactual=qp.objective(z,centers,nu)
            if controller=='qp' and not fallback and zero_feasible_guarded:
                assert jactual<=jzero+2e-5*(1+abs(jzero))
            solved.append({'vehicle':i+1,'state':states[i].tolist(),'intervals':network.cache[i].tolist(),
                           'current_joint':'graph: epsilon=b-midpoint(P0)','future_joint':'Pj x [-delta,delta]',
                           'delta':model['delta'],'old_vector':None if old is None else old.tolist(),
                           'shifted_candidate':candidate.tolist(),'executed_vector':nu.tolist(),
                           'solver':solver,'fallback_used':fallback,'physical_slack_min':float(actual_slack.min()),
                           'robust_physical_slack_min':float(slack[:qp.nphysical].min()),
                           'terminal_slack_min':float(slack[qp.nphysical:].min()),
                           'candidate_physical_slack_min':float(shifted[:qp.nphysical].min()),
                           'candidate_terminal_slack_min':float(shifted[qp.nphysical:].min()),
                           'zero_feasible':zero_feasible,'zero_feasible_guarded':zero_feasible_guarded,
                           'J_zero':jzero,'J_executed':jactual,
                           'actual_command':command,'command_difference':command-states[i,3],
                           'assembly_ms':assembly_ms,'solve_ms':solve_ms,'decision_ms':1000*(time.perf_counter()-decision_started)})
            vectors.append(nu); commands.append(command); all_slacks.append(slack); candidate_slacks.append(shifted)
        commands=np.array(commands); disturbance=OMEGA*np.sin(.4*k*T+DISTURBANCE_PHASES)
        endpos=positions_inside(k,T,positions,states,commands,disturbance,models)
        btruth=np.diff(np.c_[positions,endpos],axis=1).ravel()[:NVEH]-VREF*T
        nxt=np.zeros_like(states)
        for i,m in enumerate(models):
            aa,c,bu,q,r=kernels(T,m['tau'])
            omega=disturbance[i]
            nxt[i,1]=states[i,1]+c*states[i,2]+bu*commands[i]+q*omega
            nxt[i,2]=aa*states[i,2]+(1-aa)*commands[i]+c*omega
            nxt[i,3]=commands[i]
            gap=endpos[i]-ELL-endpos[i+1]
            nxt[i,0]=gap-D0-m['h']*(VREF+nxt[i,1])
            # Audit the exact sampled equation only after all actual motions are
            # realized. This true b is never sent to an online QP.
            w=np.array([-(m['tau']*r+m['h']*q)*omega,q*omega,c*omega,0.])
            linear_true=m['A']@states[i]+m['B']*commands[i]+m['E']*btruth[i]+w
            assert np.max(abs(linear_true-nxt[i]))<1e-8
            assert abs(nxt[i,1])<=m['Si']-T*A+VERIFY_TOL
            assert abs(nxt[i,2])<=A+VERIFY_TOL
            lo,hi=network.cache[i][0]
            assert lo-1e-9<=btruth[i]<=hi+1e-9
        grid=np.linspace(0,T,21)
        gaps=np.array([np.diff(-positions_inside(k,theta,positions,states,commands,disturbance,models))-ELL for theta in grid])
        gap_grid_min=gaps.min(axis=0)
        gap_lower=gap_grid_min-.5*(T/20)*(CONTRACT[:-1]+CONTRACT[1:])
        assert gap_lower.min()>=DSAFE-VERIFY_TOL
        for i in range(NVEH):
            solved[i]['realized_integral_after_execution']=float(btruth[i])
            solved[i]['realized_information_error_after_execution']=float(btruth[i]-network.cache[i][0].mean())
            solved[i]['continuous_gap_grid_min']=float(gap_grid_min[i])
            solved[i]['continuous_gap_certified_lower_bound']=float(gap_lower[i])
            csvrows.append({'k':k,'t_s':k*T,'vehicle':i+1,'e_m':states[i,0],'s_mps':states[i,1],
                            'a_mps2':states[i,2],'u_mps2':commands[i],'du_mps2':commands[i]-states[i,3],
                            'nu_mps2':vectors[i][0],'accepted_age_samples':service['accepted_ages'][i],
                            'current_radius_m':float((network.cache[i][0,1]-network.cache[i][0,0])/2),
                            'gap_grid_min_m':gap_grid_min[i],'gap_lower_bound_m':gap_lower[i],
                            'shifted_min_slack':float(candidate_slacks[i].min()),
                            'actual_qp_min_slack':float(all_slacks[i].min()),
                            'charged_sample_resource':service['charged_resource']})
        optrows.append(np.array([s[qp.nphysical:] for s,qp in zip(all_slacks,qps)]))
        candrows.append(np.array([s[qp.nphysical:] for s,qp in zip(candidate_slacks,qps)]))
        physicalrows.append(np.array([s[:qp.nphysical].reshape(N,qp.nr) for s,qp in zip(all_slacks,qps)]))
        records.append({'k':k,'time_s':k*T,'service':service,'controllers':solved,
                        'held_disturbance_mps3':disturbance.tolist(),'positions_start_m':positions.tolist(),
                        'positions_end_m':endpos.tolist()})
        truth.append(btruth); states=nxt; positions=endpos; previous_vectors=vectors
    truth=np.array(truth)
    future_verified=0
    for rec in records:
        k=rec['k']
        for i in range(NVEH):
            cache=rec['controllers'][i]['intervals']
            for j,(lo,hi) in enumerate(cache):
                if k+j<steps:
                    assert lo-1e-8<=truth[k+j,i]<=hi+1e-8
                    future_verified+=1
    write_json(outdir/'step_records.json',records)
    with (outdir/'trajectory.csv').open('w',newline='',encoding='utf-8') as ff:
        writer=csv.DictWriter(ff,fieldnames=list(csvrows[0])); writer.writeheader(); writer.writerows(csvrows)
    np.savez_compressed(outdir/'full_constraint_rows.npz',terminal_slacks=np.array(optrows),
                        shifted_terminal_slacks=np.array(candrows),robust_physical_slacks=np.array(physicalrows),
                        actual_predecessor_integrals=truth)
    e=np.array([r['e_m'] for r in csvrows]); uu=np.array([r['u_mps2'] for r in csvrows]); du=np.array([r['du_mps2'] for r in csvrows])
    attempted=[a for r in records for a in r['service']['attempts']]
    arrivals=[a for r in records for a in r['service']['arrivals']]
    minactual=min(r['actual_qp_min_slack'] for r in csvrows); minshift=min(r['shifted_min_slack'] for r in csvrows)
    summary={'name':name,'N':N,'selector':selector,'controller':controller,'seconds':seconds,'steps':steps,
             'realized_disturbance_bound_mps3':OMEGA,'leader_speed_formula':f'1.2*sin({frequency()}*t)^3; zero for t<0',
             'all_shifted_candidates_feasible':True,'all_actual_QPs_feasible':True,
             'minimum_shifted_constraint_slack':float(minshift),'minimum_executed_constraint_slack':float(minactual),
             'tracking_RMS_m':float(np.sqrt(np.mean(e*e))),'tracking_max_abs_m':float(abs(e).max()),
             'command_RMS_mps2':float(np.sqrt(np.mean(uu*uu))),
             'command_difference_RMS_mps2':float(np.sqrt(np.mean(du*du))),
             'command_squared_integral_proxy':float(T*np.sum(uu*uu)),
             'minimum_continuous_gap_certified_lower_bound_m':float(min(r['gap_lower_bound_m'] for r in csvrows)),
             'maximum_received_age_samples':int(max(r['accepted_age_samples'] for r in csvrows)),
             'maximum_current_radius_m':float(max(r['current_radius_m'] for r in csvrows)),
             'total_data_allocations':len(attempted),'reserved_allocations':sum(a['kind']=='reserved' for a in attempted),
             'optional_allocations':sum(a['kind']=='optional' for a in attempted),
             'optional_requests':sum(sum(r['service']['requests']) for r in records),
             'strict_interval_contractions':sum(v['strict_interval_contraction'] for r in records for v in r['service']['refinement']),
             'total_current_radius_reduction_m':float(sum(v['actual_radius_reduction'] for r in records for v in r['service']['refinement'])),
             'failed_allocations':sum(a['failed'] for a in attempted),
             'accepted_packets':sum(a['accepted'] for a in arrivals),
             'discarded_old_or_duplicate_packets':sum(not a['accepted'] for a in arrivals),
             'discarded_nonduplicate_out_of_order_packets':sum(a['discard_reason']=='nonduplicate_out_of_order_generation' for a in arrivals),
             'discarded_duplicate_packets':sum(a['discard_reason']=='duplicate_generation' for a in arrivals),
             'processed_primary_delayed_packets':sum(not a['duplicate'] and a['processed_sample']-a['generation']==1 for a in arrivals),
             'total_billed_resource':sum(r['service']['charged_resource'] for r in records),
             'total_resource_limit':steps*3,'future_slot_containment_checks':future_verified,
             'fallback_count':sum(c['fallback_used'] for r in records for c in r['controllers']),
             'zero_feasible_solve_count':sum(c['zero_feasible'] for r in records for c in r['controllers']),
             'zero_feasible_guarded_solve_count':sum(c['zero_feasible_guarded'] for r in records for c in r['controllers']),
             'initial_states_common':[[INITIAL_E if i==0 else 0.,0.,0.,0.] for i in range(NVEH)],'scenario':SCENARIO,'P':PERIOD,'random_seed':RANDOM_SEED,'initial_caches':[c.tolist() for c in init],
             'numeric_row_guard':NUMERIC_GUARD,'constraint_verification_tolerance':VERIFY_TOL,
             'continuous_gap_bound_method':'21 exact within-sample position samples; nearest-grid Lipschitz deduction with spacing 0.005 s',
             'offline_and_startup_preparation_ms':preparation_ms,'solver_matrices_reused':True,
             'prepared_initial_witness_rechecked_after_current_packet_processing':True,
             'elapsed_seconds':time.perf_counter()-begin}
    write_json(outdir/'summary.json',summary)
    print(json.dumps({'completed':name,'steps':steps,'tracking_RMS_m':summary['tracking_RMS_m'],
                      'minimum_shifted_slack':minshift,'gap_lower_bound_m':summary['minimum_continuous_gap_certified_lower_bound_m']},indent=2),flush=True)
    return summary

def check_gate(models):
    path=ROOT/'validation_gate.json'
    if not path.exists(): raise RuntimeError('Closed-loop simulation blocked: no validation_gate.json')
    gate=json.loads(path.read_text(encoding='utf-8'))
    if gate.get('THEORY_STATUS')!='FROZEN' or gate.get('DESIGN_STATUS')!='FEASIBLE':
        raise RuntimeError('Closed-loop simulation blocked: theory/design gate is not FROZEN/FEASIBLE')
    if gate.get('model_sha256'):
        for model in models:
            if gate['model_sha256'].get(model['path'])!=model['sha256']:
                raise RuntimeError('Closed-loop simulation blocked: certified model hash mismatch')
    return gate

