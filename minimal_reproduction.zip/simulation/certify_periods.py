from pathlib import Path
import json,sys,tempfile,hashlib,math
import numpy as np
import terminal_design_extended as td
from reproduce_certificate import independently_verify_stored
import enhanced_engine as eng
from scipy.optimize import linprog
HERE=Path(__file__).resolve().parent
def normalize(data):
    m={key:np.array(value,copy=True) for key,value in data.items()}
    for name in ['L','tau','h','beta','delta','Si']:m[name]=float(m[name])
    for name in ['B','E','K','G','g','hf','W_halfwidth']:m[name]=m[name].ravel()
    m['r_u']=1/1.8**2;m['r_nu']=25.
    return m
def main():
    reproduction=json.loads((HERE/'validation_summary.json').read_text(encoding='utf-8'))
    assert reproduction['simulation_status']=='COMPLETED' and len(reproduction['cases'])==7
    original=json.loads((HERE/'terminal_certificate.json').read_text(encoding='utf-8'))
    results=[]
    for period,delta in [(2,'.12'),(3,'.16'),(4,'.20'),(5,'.24')]:
        folder=HERE/'period_models'/f'P{period}';folder.mkdir(parents=True,exist_ok=True)
        vehicles=[];checks=[]
        try:
            eng.PERIOD=period;eng.PHASES=np.array([0,0,1])
            for i,v in enumerate(original['vehicles'],1):
                data,cert=td.run(v['tau'],v['K_roundtrip'],v['q_norm'],str(v['operating_speed_previous']),str(v['operating_speed_own']),delta)
                direct=independently_verify_stored(data,v['tau'],v['K_roundtrip'],str(v['operating_speed_previous']),str(v['operating_speed_own']),delta)
                path=folder/f'vehicle_{i}.npz';np.savez_compressed(path,**data)
                cert['stored_independent_check']=direct;cert['model_sha256']=hashlib.sha256(path.read_bytes()).hexdigest();vehicles.append(cert)
                m=normalize(data);qp=eng.CondensedQP(m,10);cache=eng.initial_cache(m,i-1,10)
                rhs,linear,z,centers=qp.build(np.zeros(4),cache)
                lp=linprog(np.zeros(10),A_ub=qp.C,b_ub=rhs-eng.NUMERIC_GUARD,bounds=[(-.2,.2)]*10,method='highs')
                vector,status=qp.solve(rhs,linear,np.zeros(10))
                check={'vehicle':i,'zero_min_slack':float(rhs.min()),'LP_success':bool(lp.success),'QP_status':status,
                       'QP_success':vector is not None,'initial_cache':cache.tolist()}
                assert rhs.min()>0 and lp.success and vector is not None;checks.append(check)
            active=[i+1 for i,v in enumerate(vehicles) if float(delta)<v['beta']]
            allowance=int(math.floor((float(delta)/.02)-.5+1e-12))
            pmax=None if not active else (allowance-1)//2
            rec={'P':period,'delta_req_formula':.02*(2*period+1.5),'delta':float(delta),'active_links':active,
                 'P_min':2,'P_max':pmax,'P_max_is_infinite':not active,'M':2,'phases':[0,0,1],
                 'residual_transactions_per_period':2*period-3,'DESIGN_STATUS':'FEASIBLE','vehicles':vehicles,
                 'initial_QP_checks':checks,'all_certificate_and_initial_checks_passed':True}
            assert pmax is None or period<=pmax
        except Exception as exc:
            rec={'P':period,'delta':float(delta),'DESIGN_STATUS':'INFEASIBLE','failure':repr(exc),'vehicles_checked':vehicles,'initial_QP_checks':checks}
        (folder/'design.json').write_text(json.dumps(rec,indent=2),encoding='utf-8');results.append(rec)
        print(json.dumps({k:rec.get(k) for k in ['P','delta','DESIGN_STATUS','active_links','P_max','P_max_is_infinite','failure']}),flush=True)
    (HERE/'period_design_results.json').write_text(json.dumps({'fixed_hardware_and_disturbance':True,'periods':results},indent=2),encoding='utf-8')
if __name__=='__main__':main()
