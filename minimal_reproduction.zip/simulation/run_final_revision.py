"""Minimal new C1/C2 evidence. No tuning, new random seeds or old-run replay.

Only network service changes in mixed-link runs. Metadata stays enabled.
Budget/set and fixed-budget communication effects are separately labelled.
"""
from pathlib import Path
import sys,tempfile,json,hashlib,traceback,csv,time
ROOT=Path(__file__).resolve().parents[1];HERE=ROOT/'simulation'
sys.path.insert(0,str(ROOT/'audit'))
import numpy as np
from scipy.optimize import linprog
import enhanced_engine as eng
from run_enhancements import models_for
from certify_periods import normalize
from run_targeted_diagnostics import ProductCurrentQP
from terminal_design_extended import I
BASE=eng.Network;QP=eng.CondensedQP
def dump(p,o):p.write_text(json.dumps(o,indent=2,ensure_ascii=False,allow_nan=False),encoding='utf-8')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
class ActiveOnlyNetwork(BASE):
    """J-only mandatory opportunities, no optional attempts, fixed metadata.
    Inactive speeds are never accessed by transmission, request or cache code.
    Original process/attempt functions retain failure/delay/ACK semantics.
    """
    def sample(self,k,speeds):
        new,events=self.process(k,'early');score_ack=self.ack.copy();acks=[]
        active=[i for i,m in enumerate(self.models) if m['delta']<m['beta']-1e-15]
        for i in range(3):
            lost=(k+i)%7==3
            if not lost and self.latest[i]>=self.ack[i]:
                self.ack[i]=self.latest[i];self.ack_speed[i]=self.sent[i][int(self.latest[i])]
            acks.append(dict(link=i+1,lost=lost,visible_generation=int(self.ack[i])))
        reserved=[i for i in active if k%eng.PERIOD==eng.PHASES[i]]
        assert len(reserved)<=eng.M
        attempts=[self.attempt(k,i,speeds[i],'reserved') for i in reserved]
        newer,ev=self.process(k,'accept');events+=ev
        for i in range(3):new[i]+=newer[i]
        previous=[c.copy() for c in self.cache];ref=[]
        for i,m in enumerate(self.models):
            now=self.cache[i].copy() if k==0 else np.vstack([self.cache[i][1:],[-m['beta'],m['beta']]])
            for pkt in new[i]+[dict(generation=int(self.latest[i]),speed=float(self.snapshot[i]))]:
                for j in range(self.N):
                    snap=eng.snapshot_interval(m,k,j,pkt['generation'],pkt['speed'])
                    now[j,0]=max(now[j,0],snap[0]);now[j,1]=min(now[j,1],snap[1])
            assert np.all(now[:,0]<=now[:,1])
            radius=float((now[0,1]-now[0,0])/2);assert radius<=m['delta']+1e-12
            if i in active:assert k-self.latest[i]<=(eng.BF+1)*eng.PERIOD+eng.DELAY
            if k:
                assert np.all(now[:-1,0]>=previous[i][1:,0]-1e-12) and np.all(now[:-1,1]<=previous[i][1:,1]+1e-12)
            self.cache[i]=now
            ref.append(dict(link=i+1,accepted_new_generations=[p['generation'] for p in new[i]],radius_after_all_accepted_packets=radius,
                radius_without_new_packet=radius,actual_radius_reduction=0.,strict_interval_contraction=False,
                note='Contraction statistics not computed for this service-only run; raw cache retained.'))
        return dict(requests=[False]*3,scores=[0.]*3,eligible=[],reserved=[i+1 for i in reserved],selected_optional=[],attempts=attempts,arrivals=events,
            ack_events=acks,allocated=len(attempts),charged_resource=1+len(attempts),metadata_resource=1,capacity_resource=3,
            accepted_generation=self.latest.tolist(),accepted_ages=(k-self.latest).tolist(),visible_ack_generation=self.ack.tolist(),
            score_ack_generation=score_ack.tolist(),score_ack_speed_mps=self.ack_speed.tolist(),cache_before_shift=[p.tolist() for p in previous],
            refinement=ref,mandatory_links=[i+1 for i in active],metadata_frame_enabled=True,
            inactive_current_speed_argument_used=False,service_mode='active-link-only')
def load_budget(name):
    out=[]
    for i in range(3):
        p=HERE/'budget_models'/name/f'vehicle_{i+1}.npz'
        with np.load(p) as z:m=normalize({key:z[key].copy() for key in z.files})
        m.update(path=str(p.relative_to(HERE)),sha256=sha(p));out.append(m)
    return out
def configure(P,e=0.,network=ActiveOnlyNetwork):
    eng.PERIOD=P;eng.INITIAL_E=e;eng.SCENARIO='mild';eng.RANDOM_SEED=20261014
    eng.Network=network;eng.CondensedQP=QP
def initial_checks(models,e):
    out=[]
    for i,m in enumerate(models):
        x=np.array([e if i==0 else 0.,0.,0.,0.]);cache=eng.initial_cache(m,i,10);q=QP(m,10);rhs,linear,z,c=q.build(x,cache)
        lp=linprog(np.zeros(10),A_ub=q.C,b_ub=rhs-1e-7,bounds=[(-.2+1e-7,.2-1e-7)]*10,method='highs')
        nu,status=q.solve(rhs,linear,lp.x if lp.success else np.zeros(10))
        assert lp.success and nu is not None and q.slack(rhs,nu).min()>=0
        row=int(np.argmin(rhs));zero_lower=I.fixed_float(rhs[row])
        out.append(dict(vehicle=i+1,state=x.tolist(),cache=cache.tolist(),LP_success=True,QP_success=True,solver=status,
            correction=nu.tolist(),zero_min_slack=float(rhs.min()),zero_violated_row=row,zero_row_signed_slack_interval=[str(zero_lower.lo),str(zero_lower.hi)],
            minimum_robust_physical_slack=float(q.slack(rhs,nu)[:130].min()),minimum_terminal_slack=float(q.slack(rhs,nu)[130:].min()),
            actual_command=float(m['K']@x+m['L']*c[0]+nu[0]),physical_gap_m=35.+x[0]))
    return out
def complete_records(folder,models):
    events=json.loads((folder/'step_records.json').read_text());qps=[QP(m,10) for m in models]
    rhs_all=[];linear_all=[];ex=[];sh=[];actual=[];maxdiff=0.;bound=[]
    for k,r in enumerate(events):
        rr=[];ll=[];ee=[];ss=[];aa=[]
        for i,(m,q,c) in enumerate(zip(models,qps,r['controllers'])):
            x=np.array(c['state']);cache=np.array(c['intervals']);nu=np.array(c['executed_vector']);cand=np.array(c['shifted_candidate'])
            rhs,linear,z,cent=q.build(x,cache);s=q.slack(rhs,nu);cs=q.slack(rhs,cand)
            assert s.min()>=0 and cs.min()>=0 and max(abs(nu))<=.2 and max(abs(cand))<=.2
            if k:assert np.array_equal(cand,np.r_[events[k-1]['controllers'][i]['executed_vector'][1:],0.])
            u=float(m['K']@x+m['L']*cent[0]+nu[0]);assert abs(u-c['actual_command'])<1e-12
            a=m['g']-m['H']@x-m['G']*u;assert a.min()>=0
            if k:assert x[3]==events[k-1]['controllers'][i]['actual_command']
            assert c['continuous_gap_certified_lower_bound']>=10
            # Directed exact-binary check of every condensed row close to guard.
            for vector,slack,label in [(nu,s,'executed'),(cand,cs,'shifted')]:
                for row in np.flatnonzero(slack<2e-7):
                    res=I.fixed_float(rhs[row])-sum((I.fixed_float(v)*I.fixed_float(a_) for v,a_ in zip(q.C[row],vector)),I(0))
                    assert res.lo>0
                    bound.append(dict(k=k,vehicle=i+1,kind=label,row=int(row),float_slack=float(slack[row]),directed_80digit_lower=str(res.lo)))
            rr.append(rhs);ll.append(linear);ee.append(s);ss.append(cs);aa.append(a)
        rhs_all.append(rr);linear_all.append(ll);ex.append(ee);sh.append(ss);actual.append(aa)
    ex=np.array(ex);sh=np.array(sh)
    with np.load(folder/'full_constraint_rows.npz') as z:
        assert np.array_equal(ex[:,:,130:],z['terminal_slacks']) and np.array_equal(sh[:,:,130:],z['shifted_terminal_slacks'])
        assert np.array_equal(ex[:,:,:130].reshape(len(events),3,10,13),z['robust_physical_slacks'])
    np.savez_compressed(folder/'complete_decision_records.npz',C=np.array([q.C for q in qps]),Hessian=np.array([q.Hess for q in qps]),
        linear_terms=np.array(linear_all),right_hand_sides=np.array(rhs_all),executed_rows=ex,shifted_rows=sh,actual_physical_rows=np.array(actual),
        executed_correction_box_slacks=np.array([[.2-abs(np.array(c['executed_vector'])) for c in r['controllers']] for r in events]))
    dump(folder/'near_guard_interval_checks.json',dict(precision_digits=80,checks=bound,scope='Exact stored binary64 condensed row/decision/RHS; does not certify unrounded support assembly or all machine paths.'))
    rows=list(csv.DictReader((folder/'trajectory.csv').open()));metric=dict(tracking_RMS_m=float(np.sqrt(np.mean([float(r['e_m'])**2 for r in rows]))),
        command_difference_RMS_mps2=float(np.sqrt(np.mean([float(r['du_mps2'])**2 for r in rows]))),command_squared_integral_proxy=.1*sum(float(r['u_mps2'])**2 for r in rows))
    summary=json.loads((folder/'summary.json').read_text());assert max(abs(metric[k]-summary[k]) for k in metric)<1e-12
    metadata=sum(r['service']['metadata_resource'] for r in events);data=sum(len(r['service']['attempts']) for r in events)
    assert summary['total_billed_resource']==metadata+data
    return dict(all_passed=True,metadata=metadata,data=data,total=metadata+data,rows_checked=int(ex.size+sh.size),post_initial_candidates=(len(events)-1)*3,
        metrics_recomputed_from_csv=metric,near_guard_interval_checks=len(bound),minimum_executed_slack=float(ex.min()),minimum_shifted_slack=float(sh.min()))
def product_initial_witness(models,e):
    m=models[0];cache=eng.initial_cache(m,0,10);x=np.array([e,0.,0.,0.]);q=ProductCurrentQP(m,10)
    rhs,lin,z,c=q.build(x,cache);lp=linprog(np.zeros(10),A_ub=q.C,b_ub=rhs,bounds=[(-.2,.2)]*10,method='highs')
    row=int(np.argmin(rhs+.2*np.sum(abs(q.C),axis=1)));violation=-I.fixed_float(rhs[row])-sum((I.fixed_float(v).abs()*I.fixed_float(.2) for v in q.C[row]),I(0))
    assert not lp.success and violation.lo>0
    return dict(state=x.tolist(),same_available_cache=cache.tolist(),LP_success=lp.success,LP_status=lp.message,
        impossible_row=row,stage=row//13,physical_row=row%13,current_radius_m=float((cache[0,1]-cache[0,0])/2),current_estimate_m=float(cache[0].mean()),
        rhs=float(rhs[row]),row_coefficients=q.C[row].tolist(),all_box_corrections_violation_lower=str(violation.lo),
        physical_initial_history='All vehicles v=25 m/s, a=u_previous=omega=0 for all t<0; gap1=35+e, other gaps=35; snapshots generated at -5,-5,-4, accepted by generation+1. No state jump at task start.',
        interpretation='Product-current cannot provide a robust certificate at this physical state; no collision trajectory is executed or inferred.')
def main():
    assert json.loads((ROOT/'audit/period_certificate_recomputation.json').read_text())['all_passed']
    assert json.loads((ROOT/'audit/budget_review.json').read_text())['all_passed']
    p5=models_for(5);uold=[{**m,'delta':.225} for m in p5];uniform=load_budget('uniform225');link=load_budget('link_beta')
    oldw=json.loads((ROOT/'source_baseline/audit/same_interface_domain_witness.json').read_text())['vehicles'][0]
    e=oldw['state'][0]
    specs=[('C1_P3_active_only',3,models_for(3),ActiveOnlyNetwork,0.),('C1_P4_active_only',4,models_for(4),ActiveOnlyNetwork,0.),
        ('C1_uniform225_old_terminal',5,uold,ActiveOnlyNetwork,0.),('C1_uniform225_rebuilt',5,uniform,ActiveOnlyNetwork,0.),
        ('C1_link_beta_rebuilt',5,link,ActiveOnlyNetwork,0.),('C1_uniform225_all_link',5,uniform,BASE,0.),
        ('C2_physical_conditioning_witness',5,p5,BASE,e)]
    outcomes=[]
    for name,P,models,network,e in specs:
        configure(P,e,network);eng.HERE=HERE/'revision_results'/name;eng.HERE.mkdir(parents=True,exist_ok=True)
        config=dict(name=name,P=P,horizon=10,seconds=18,seed=20261014,delta=[m['delta'] for m in models],beta=[m['beta'] for m in models],
            metadata_units_per_sample=1,service='active-link-only' if network is ActiveOnlyNetwork else 'all-link reserved',initial_e=e,
            physical_history='Constant v=25, a=u_previous=0, omega=0 for t<0; gaps 35+e1,35,35; no reset at t=0',
            initial_generations=[int(p)-P for p in eng.PHASES],snapshot_speeds=[0.,0.,0.],bootstrap_billed=False,
            failure='reserved index modulo4==1 fails, primary delay<=1, ACK loss (k+i)%7==3; unchanged from source',
            models=[m['sha256'] for m in models],engine_sha256=sha(HERE/'enhanced_engine.py'),wrapper_sha256=sha(Path(__file__)),
            no_performance_tuning=True,actual_future_integrals_only_recorded_after_execution=True)
        dump(eng.HERE/'configuration.json',config)
        try:
            initial=initial_checks(models,e);dump(eng.HERE/'initialization.json',initial)
            if name.startswith('C2_'):dump(eng.HERE/'product_current_initial_infeasibility.json',product_initial_witness(models,e))
            result=eng.run_case(models,10,'reserved','qp',18.)
            folder=eng.HERE/'results'/result['name'];checked=complete_records(folder,models)
            result.update(group=name,status='COMPLETED',audit=checked,configuration=config)
            dump(folder/'summary.json',result);outcomes.append(result)
        except Exception as exc:
            failure=dict(group=name,status='FAILED',error=repr(exc),traceback=traceback.format_exc(),configuration=config)
            tb=exc.__traceback__
            while tb:
                loc=tb.tb_frame.f_locals
                if tb.tb_frame.f_code.co_name=='run_case':
                    dump(eng.HERE/'partial_step_records.json',loc.get('records',[]))
                    failure['failed_sample']=loc.get('k');failure['last_completed_records']=len(loc.get('records',[]))
                    if 'states' in loc:failure['state_at_failure']=loc['states'].tolist()
                tb=tb.tb_next
            dump(eng.HERE/'failure.json',failure);outcomes.append(failure)
        dump(HERE/'revision_summary.json',dict(cases=outcomes,all_completed=len(outcomes)==len(specs) and all(x['status']=='COMPLETED' for x in outcomes)))
        print(json.dumps({k:outcomes[-1].get(k) for k in ['group','status','tracking_RMS_m','total_billed_resource','error']}),flush=True)
    assert all(x['status']=='COMPLETED' for x in outcomes)
if __name__=='__main__':main()
