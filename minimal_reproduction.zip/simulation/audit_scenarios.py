"""Prespecified admissible leader profiles. No tuning from outcome metrics."""
import math
SCENARIOS={
 'paired_pulses':dict(P=3,service='original',description='Raised-cosine positive pulse on [0,4.8], negative pulse on [7,11.8], zero otherwise',amplitude=1.4,duration=4.8,starts=[0.,7.],signs=[1.,-1.],speed_bound=1.4,acceleration_bound=1.4*(22/7)/4.8),
 'near_accel_pulses':dict(P=4,service='original',description='Alternating raised-cosine pulses at 0,3,6,9,12,15 seconds, each duration2.3 and magnitude1.4',amplitude=1.4,duration=2.3,starts=[0.,3.,6.,9.,12.,15.],signs=[1.,-1.,1.,-1.,1.,-1.],speed_bound=1.4,acceleration_bound=1.4*(22/7)/2.3),
 'mixed_frequency_worst_service':dict(P=3,service='worst',description='0.8 sin^3(0.9t)+0.6 sin^3(1.3t); alternating reserved failures, every primary success delayed one sample',components=[(.8,.9),(.6,1.3)],speed_bound=1.4,acceleration_bound=3/1.73)
}
def values(name,t):
    """Return deviation speed, acceleration and integrated deviation position."""
    if t<0:return 0.,0.,0.
    if name=='original_mild':
        w=.35;A=1.2;co=math.cos(w*t)
        return A*math.sin(w*t)**3,3*A*w*math.sin(w*t)**2*math.cos(w*t),A/w*(2/3-co+co**3/3)
    c=SCENARIOS[name]
    if 'components' in c:
        s=a=p=0.
        for A,w in c['components']:
            co=math.cos(w*t);s+=A*math.sin(w*t)**3;a+=3*A*w*math.sin(w*t)**2*co;p+=A/w*(2/3-co+co**3/3)
        return s,a,p
    s=a=p=0.;A=c['amplitude'];D=c['duration'];w=2*math.pi/D
    for start,sign in zip(c['starts'],c['signs']):
        u=min(max(t-start,0.),D)
        p+=sign*A/2*(u-math.sin(w*u)/w)
        if start<=t<=start+D:s+=sign*A/2*(1-math.cos(w*u));a+=sign*A*w/2*math.sin(w*u)
    return s,a,p
def verify_declared_profiles():
    # pi<22/7; sqrt(3)>1.73. Pulse supports do not overlap.
    for name,c in SCENARIOS.items():
        assert c['speed_bound']<1.5 and c['acceleration_bound']<2.
        assert values(name,-1.)==(0.,0.,0.) and max(abs(x) for x in values(name,0.))<1e-14
        if 'starts' in c:assert all(b>=a+c['duration'] for a,b in zip(c['starts'],c['starts'][1:]))
    return dict(all_in_declared_domain=True,leader_speed_envelope_mps=1.5,leader_accel_envelope_mps2=2.,
        proof='Nonoverlapping pulse extrema |s|<=1.4, |a|<=1.4*pi/duration<1.4*(22/7)/duration; sum sin^3 bound |s|<=1.4, |a|<=2*(.8*.9+.6*1.3)/sqrt(3)<3/1.73.',
        leader_is_external='Only external speed/acceleration envelopes are assumed for vehicle0; follower actuator/input constraints remain unchanged.')
