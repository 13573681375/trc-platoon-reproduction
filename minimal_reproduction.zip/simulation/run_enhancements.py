"""Only certified periods and checked initial states may enter these runs."""
from pathlib import Path
import json,sys,tempfile,hashlib,traceback,time,platform
import numpy as np
from scipy.optimize import linprog
import enhanced_engine as eng
from certify_periods import normalize
HERE=Path(__file__).resolve().parent
def models_for(period):
    folder=HERE/'period_models'/f'P{period}'
    design=json.loads((folder/'design.json').read_text(encoding='utf-8'))
    assert design['DESIGN_STATUS']=='FEASIBLE' and design['all_certificate_and_initial_checks_passed']
    models=[]
    for i,v in enumerate(design['vehicles'],1):
        path=folder/f'vehicle_{i}.npz';assert hashlib.sha256(path.read_bytes()).hexdigest()==v['model_sha256']
        with np.load(path,allow_pickle=False) as z: m=normalize({key:z[key].copy() for key in z.files})
        m['path']=str(path.relative_to(HERE));m['sha256']=v['model_sha256'];models.append(m)
    return models
def initialize(models,N,e1,zero_required=False):
    checks=[]
    for i,m in enumerate(models):
        x=np.zeros(4);x[0]=e1 if i==0 else 0.
        cache=eng.initial_cache(m,i,N);qp=eng.CondensedQP(m,N);rhs,lin,z,cent=qp.build(x,cache)
        lp=linprog(np.zeros(N),A_ub=qp.C,b_ub=rhs-eng.NUMERIC_GUARD,bounds=[(-.2+eng.NUMERIC_GUARD,.2-eng.NUMERIC_GUARD)]*N,method='highs')
        nu,status=qp.solve(rhs,lin,np.zeros(N) if not lp.success else lp.x)
        rec={'vehicle':i+1,'N':N,'state':x.tolist(),'cache':cache.tolist(),'LP_success':bool(lp.success),
             'QP_success':nu is not None,'solver':status,'zero_min_slack':float(rhs.min()),
             'QP_min_slack':None if nu is None else float(qp.slack(rhs,nu).min()),
             'QP_vector':None if nu is None else nu.tolist()}
        assert lp.success and nu is not None and (not zero_required or rhs.min()>=eng.NUMERIC_GUARD)
        checks.append(rec)
    return checks
def run_one(group,P,N,selector,controller,scenario,e1=0.,seed=20261014):
    eng.PERIOD=P;eng.SCENARIO=scenario;eng.INITIAL_E=e1;eng.RANDOM_SEED=seed
    eng.HERE=HERE/'enhanced_results'/group;eng.HERE.mkdir(parents=True,exist_ok=True)
    models=models_for(P);checks=initialize(models,N,e1,controller=='zero')
    (eng.HERE/f'initialization_N{N}_{controller}_{selector}.json').write_text(json.dumps(checks,indent=2),encoding='utf-8')
    result=eng.run_case(models,N,selector,controller,18.)
    result.update(group=group,model_hashes={m['path']:m['sha256'] for m in models},
                  actual_engine_sha256=hashlib.sha256((HERE/'enhanced_engine.py').read_bytes()).hexdigest(),
                  initial_QP_checks=checks,analytic_leader_max_acceleration=2*1.2*eng.frequency()/np.sqrt(3))
    path=eng.HERE/'results'/result['name']
    records=json.loads((path/'step_records.json').read_text(encoding='utf-8'))
    timings={}
    for key in ('assembly_ms','solve_ms','decision_ms'):
        vals=[c[key] for r in records for c in r['controllers']]
        timings[key]={'mean':float(np.mean(vals)),'p95':float(np.percentile(vals,95)),'maximum':float(np.max(vals)),
                      'sample_count':len(vals),'includes_first_OSQP_setup':False}
    result['timing']=timings
    result['timing_scope']='Per-vehicle build, candidate/solution verification and cost evaluation; excludes shared network processing, plant integration, logging and offline/startup solver preparation, which is reported separately.'
    (path/'summary.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
    return result
def main():
    specs=[]
    for P in (2,3,4,5):specs.append((f'C1_P{P}',P,10,'reserved','qp','mild',0.,20261014))
    for N in (1,2,10):specs.append((f'C2_rate_active_N{N}',2,N,'proposed','qp','boundary',2.033561451573983,20261014))
    for ctrl in ('qp','zero'):specs.append((f'C3_common_boundary_{ctrl}',2,10,'reserved',ctrl,'boundary',1.70,20261014))
    for seed in (20261015,20261016):specs.append((f'C4_random_seed{seed}',2,10,'random','qp','mild',0.,seed))
    results=[]
    for spec in specs:
        try: results.append({'status':'COMPLETED',**run_one(*spec)})
        except Exception as exc:
            results.append({'status':'FAILED','specification':list(spec),'error':repr(exc),'traceback':traceback.format_exc()})
            print(json.dumps(results[-1]),flush=True)
        (HERE/'enhancement_summary.json').write_text(json.dumps({'date':'2026-10-14','cases':results,
          'machine':{'processor':'AMD Ryzen 9 8945HX','physical_cores':16,'logical_processors':32,'RAM_GB':31.80,
                     'platform':platform.platform(),'python':platform.python_version()},
          'all_requested_cases_completed':all(r['status']=='COMPLETED' for r in results),'no_constraint_rows_pruned':True},indent=2),encoding='utf-8')
if __name__=='__main__':main()
