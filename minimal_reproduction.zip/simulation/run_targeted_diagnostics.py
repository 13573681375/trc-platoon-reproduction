"""Minimal P1 experiments. Original engine/code/data are preserved unchanged.
All use the P5 5200-facet sets, identical plant/cost/K/correction class.
Snapshot-only retains the billed metadata frame; no frame-free run is claimed.
Legacy no_preview group changes only L to zero and still predicts E*c_j: it is gain-only. True preview-use-off is run_preview_off.py.
Product-current is explicitly an outer-uncertainty ablation, not an author's
or Luo--Lam's reproduced method. All failures and partial logs are retained.
"""
from pathlib import Path
import sys,json,tempfile,time,hashlib,traceback
ROOT=Path(__file__).resolve().parents[1];HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'audit'))
import numpy as np
from scipy.optimize import linprog
import enhanced_engine as eng
from run_enhancements import models_for
from verify_shared_terminal import independently_verify_stored
OriginalQP=eng.CondensedQP;OriginalNetwork=eng.Network
def write(path,obj):path.write_text(json.dumps(obj,indent=2,allow_nan=False),encoding='utf-8')
class ProductCurrentQP(OriginalQP):
    """Use P0 x [-delta,delta] instead of its known-estimate graph.
    C, Hessian, nominal objective and correction decision variables are identical
    on the same state/cache. Only the conservative robust RHS changes.
    """
    def prepare_support(self,rows,j):
        d=self.m['E']+self.m['B']*self.m['L'];bl=self.m['B']*self.m['L']
        coeff=np.zeros((len(rows),self.N));base=np.zeros(len(rows))
        for t in range(j):
            rr=rows@self.fp[j-1-t];coeff[:,t]=abs(rr@d)
            base+=self.m['delta']*abs(rr@bl)+abs(rr)@self.m['W_halfwidth']
        return coeff,base
    def build(self,x,cache):
        rhs,lin,z,cent=super().build(x,cache)
        rad0=(cache[0,1]-cache[0,0])/2
        rhs[:self.nr]-=abs(self.m['G']*self.m['L'])*(rad0+self.m['delta'])
        return rhs,lin,z,cent
class SnapshotOnlyNetwork(OriginalNetwork):
    """Valid pre-task zero-speed snapshots only. Ignore current speed argument."""
    def sample(self,k,speeds):
        del speeds  # no current/true/future predecessor measurements after init
        assert all(m['beta']<=m['delta'] for m in self.models)
        previous=[c.copy() for c in self.cache];ref=[]
        for i,m in enumerate(self.models):
            now=self.cache[i].copy() if k==0 else np.vstack([self.cache[i][1:],[-m['beta'],m['beta']]])
            for j in range(self.N):
                snap=eng.snapshot_interval(m,k,j,int(self.latest[i]),float(self.snapshot[i]))
                now[j,0]=max(now[j,0],snap[0]);now[j,1]=min(now[j,1],snap[1])
            assert np.all(now[:,0]<=now[:,1]) and (now[0,1]-now[0,0])/2<=m['delta']+1e-12
            if k and self.N>1:
                assert np.all(now[:-1,0]>=previous[i][1:,0]-1e-12) and np.all(now[:-1,1]<=previous[i][1:,1]+1e-12)
            self.cache[i]=now
            rad=float((now[0,1]-now[0,0])/2)
            ref.append(dict(link=i+1,accepted_new_generations=[],radius_without_new_packet=rad,
                            radius_after_all_accepted_packets=rad,actual_radius_reduction=0.,strict_interval_contraction=False))
        return dict(requests=[False]*3,scores=[0.]*3,eligible=[],reserved=[],selected_optional=[],
             attempts=[],arrivals=[],ack_events=[],allocated=0,charged_resource=1,
             metadata_resource=1,capacity_resource=3,accepted_generation=self.latest.tolist(),
             accepted_ages=(k-self.latest).tolist(),visible_ack_generation=self.ack.tolist(),
             score_ack_generation=self.ack.tolist(),score_ack_speed_mps=self.ack_speed.tolist(),
             cache_before_shift=[c.tolist() for c in previous],refinement=ref,
             metadata_frame_enabled=True,metadata_content='Fixed empty status frame; no data requests or new acknowledgements',
             diagnostic_only=True,post_initial_speed_argument_used=False)
def configure(qpclass=OriginalQP,network=OriginalNetwork):
    eng.CondensedQP=qpclass;eng.Network=network;eng.PERIOD=5;eng.SCENARIO='mild';eng.INITIAL_E=0.;eng.RANDOM_SEED=20261014
def initial_checks(models,qpclass,controller):
    results=[]
    for i,m in enumerate(models):
        qp=qpclass(m,10);cache=eng.initial_cache(m,i,10);rhs,lin,z,c=qp.build(np.zeros(4),cache)
        lp=linprog(np.zeros(10),A_ub=qp.C,b_ub=rhs-1e-7,bounds=[(-.2+1e-7,.2-1e-7)]*10,method='highs')
        nu,status=qp.solve(rhs,lin,np.zeros(10) if not lp.success else lp.x)
        results.append(dict(vehicle=i+1,LP_success=bool(lp.success),QP_success=nu is not None,
             zero_min_raw_slack=float(rhs.min()),LP_vector=None if not lp.success else lp.x.tolist(),
             QP_vector=None if nu is None else nu.tolist(),solver=status,cache=cache.tolist(),
             installed_generation=int(eng.PHASES[i])-5,physical_prehistory='v=25 m/s, a=u_previous=0, gap=35 m; disturbance=0 before t=0'))
        assert lp.success and nu is not None and (controller!='zero' or rhs.min()>=0)
    return results
def audit_trace(folder,models,qpclass):
    records=json.loads((folder/'step_records.json').read_text());qps=[qpclass(m,10) for m in models]
    executed=[];candidates=[];right=[];physical=[];terminal=[];truth=[];maxdiff=0.;rowcount=0
    for k,r in enumerate(records):
        ss=[];cs=[];rrs=[];aps=[]
        assert r['service']['charged_resource']==r['service']['metadata_resource']+len(r['service']['attempts'])
        for i,(m,qp,c) in enumerate(zip(models,qps,r['controllers'])):
            x=np.array(c['state']);cache=np.array(c['intervals']);nu=np.array(c['executed_vector']);cand=np.array(c['shifted_candidate'])
            rhs,linear,z,cent=qp.build(x,cache);s=qp.slack(rhs,nu);shift=qp.slack(rhs,cand)
            assert s.min()>=0 and shift.min()>=0 and max(abs(nu))<=.2
            if k:assert np.array_equal(cand,np.r_[records[k-1]['controllers'][i]['executed_vector'][1:],0.])
            u=float(m['K']@x+m['L']*cent[0]+nu[0]);assert abs(u-c['actual_command'])<1e-12
            actual=m['g']-m['H']@x-m['G']*u;assert actual.min()>=0
            if k+1<len(records):assert records[k+1]['controllers'][i]['state'][3]==u
            assert c['continuous_gap_certified_lower_bound']>=10
            b=c['realized_integral_after_execution'];assert cache[0,0]-1e-8<=b<=cache[0,1]+1e-8
            if k+1<len(records):
                omega=r['held_disturbance_mps3'][i];ta=m['tau'];decay=np.exp(-.1/ta);cc=ta*(1-decay);qq=ta*(.1-cc);ri=.005-qq
                w=np.array([-(ta*ri+m['h']*qq)*omega,qq*omega,cc*omega,0.])
                nxt=m['A']@x+m['B']*u+m['E']*b+w
                assert max(abs(nxt-np.array(records[k+1]['controllers'][i]['state'])))<1e-8
            ss.append(s);cs.append(shift);rrs.append(rhs);aps.append(actual);rowcount+=len(s)+len(shift)+13
        executed.append(ss);candidates.append(cs);right.append(rrs);physical.append(aps)
        truth.append([c['realized_integral_after_execution'] for c in r['controllers']])
    with np.load(folder/'full_constraint_rows.npz') as z:old={key:z[key].copy() for key in z.files}
    exe=np.array(executed);can=np.array(candidates)
    maxdiff=max(float(np.max(abs(exe[:,:,130:]-old['terminal_slacks']))),
                float(np.max(abs(can[:,:,130:]-old['shifted_terminal_slacks']))),
                float(np.max(abs(exe[:,:,:130]-old['robust_physical_slacks'].reshape(180,3,130)))))
    assert maxdiff==0
    # Add the complete shifted physical rows and RHS, preserving original arrays.
    np.savez_compressed(folder/'complete_decision_records.npz',
        executed_rows=exe,shifted_rows=can,right_hand_sides=np.array(right),actual_physical_rows=np.array(physical),
        actual_integrals_after_execution=np.array(truth),correction_constraint_matrix=qps[0].C)
    return dict(all_passed=True,decisions=540,post_initial_saved_candidates=537,full_rows_checked=rowcount,
                original_saved_row_array_difference=maxdiff,minimum_executed_slack=float(exe.min()),
                minimum_shifted_slack=float(can.min()),all_5200_terminal_rows_retained=True)
def check_shared_no_preview(models):
    original=json.loads((HERE/'terminal_certificate.json').read_text());out=[]
    for i,(m,v) in enumerate(zip(models,original['vehicles']),1):
        assert m['beta']<=.24
        direct=independently_verify_stored(m,v['tau'],v['K_roundtrip'],str(v['operating_speed_previous']),str(v['operating_speed_own']),'.24','0')
        out.append(dict(vehicle=i,verified_L_zero_on_unchanged_P5_terminal=True,stored=direct,
                 subset_argument='E b = (E+B*.25)b - B*.25*epsilon with epsilon=b, |b|<=beta<=delta=.24'))
    write(ROOT/'audit/no_preview_shared_terminal_certificate.json',dict(all_passed=True,vehicles=out))
def frozen_contexts(models,reference_folder):
    r=json.loads((reference_folder/'step_records.json').read_text());out=[]
    for k in (0,89,179):
        for i,m in enumerate(models):
            c=r[k]['controllers'][i];x=np.array(c['state']);cache=np.array(c['intervals']);normal=OriginalQP(m,10)
            nrhs,nlin,nz,ncent=normal.build(x,cache);reference_nu=np.array(c['executed_vector'])
            pair={}
            for name,klass,mm in [('conditional',OriginalQP,m),('current_product',ProductCurrentQP,m),('no_preview',OriginalQP,{**m,'L':0.})]:
                qp=klass(mm,10);rhs,lin,z,cent=qp.build(x,cache)
                assert np.array_equal(qp.C,normal.C) and np.array_equal(qp.Hess,normal.Hess)
                lp=linprog(np.zeros(10),A_ub=qp.C,b_ub=rhs-1e-7,bounds=[(-.2+1e-7,.2-1e-7)]*10,method='highs')
                nu,status=qp.solve(rhs,lin,lp.x if lp.success else reference_nu)
                pair[name]=dict(L=mm['L'],LP_success=bool(lp.success),QP_success=nu is not None,solver=status,
                               correction=None if nu is None else nu.tolist(),
                               nominal_objective=None if nu is None else qp.objective(z,cent,nu),
                               zero_feasible=bool(rhs.min()>=0),maximum_RHS_change=float(max(abs(rhs-nrhs))))
                if name=='current_product':assert np.all(rhs<=nrhs+2e-12) and np.array_equal(lin,nlin)
            if pair['conditional']['QP_success'] and pair['current_product']['QP_success']:
                a=pair['conditional']['nominal_objective'];b=pair['current_product']['nominal_objective'];assert a<=b+2e-5*(1+abs(b))
            out.append(dict(k=k,vehicle=i+1,identical_measured_state=x.tolist(),identical_receiver_cache=cache.tolist(),variants=pair))
    write(ROOT/'audit/frozen_context_ablation.json',dict(contexts=out,selected_contexts=[0,89,179],
        scope='Nine selected same-state/same-cache contexts; not the whole feasible domain or a traffic-scenario sample. All terminal/correction matrices and Hessians exactly equal.'))
def main():
    recert=json.loads((ROOT/'audit/period_certificate_recomputation.json').read_text());assert recert['all_passed']
    models=models_for(5);configure();check_shared_no_preview(models)
    reference_folder=HERE/'enhanced_results/C1_P5/results/N10_qp_reserved'
    reference=json.loads((reference_folder/'summary.json').read_text());rows=json.loads((reference_folder/'step_records.json').read_text())
    charges=dict(samples=len(rows),metadata_units=sum(r['service']['metadata_resource'] for r in rows),
         data_transactions=sum(len(r['service']['attempts']) for r in rows),total=sum(r['service']['charged_resource'] for r in rows))
    assert charges==dict(samples=180,metadata_units=180,data_transactions=108,total=288)
    audit=audit_trace(reference_folder,models,OriginalQP)
    write(ROOT/'audit/P5_original_ledger_and_trace.json',dict(ledger=charges,reference_trace_audit=audit,
          active_links=[],beta_m=[m['beta'] for m in models],delta_m=.24,initial_snapshots_outside_operating_ledger=True))
    frozen_contexts(models,reference_folder)
    specs=[('snapshot_only_metadata',OriginalQP,SnapshotOnlyNetwork,models,'qp'),
           ('same_interface_current_product',ProductCurrentQP,OriginalNetwork,models,'qp'),
           ('same_interface_no_preview',OriginalQP,OriginalNetwork,[{**m,'L':0.} for m in models],'qp'),
           ('same_interface_zero_correction',OriginalQP,OriginalNetwork,models,'zero')]
    outcomes=[]
    for label,qpclass,network,mm,controller in specs:
        configure(qpclass,network);folder=HERE/'targeted_results'/label;folder.mkdir(parents=True,exist_ok=True);eng.HERE=folder
        config=dict(name=label,P=5,delta_m=.24,horizon=10,seconds=18,seed=20261014,scenario='mild',
            leader='1.2*sin(.35*t)^3 for t>=0; s=0 before startup',disturbance='.2*sin(.4*k*.1+[.3,1.1,2]) after startup',
            current_uncertainty='product' if qpclass is ProductCurrentQP else 'known-estimate graph',
            L=[m['L'] for m in mm],metadata_frame_per_sample=1,data_after_init=network is not SnapshotOnlyNetwork,
            initial_generations=[-5,-5,-4],initial_snapshot_speeds=[0.,0.,0.],
            bootstrap_resource_scope='Initial snapshots assumed valid before operation; startup transactions excluded consistently with original P5 ledger.',
            formal_method_promotion=False,engine_sha256=hashlib.sha256((HERE/'enhanced_engine.py').read_bytes()).hexdigest(),
            wrapper_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            terminal_model_sha256=[m['sha256'] for m in mm])
        write(folder/'configuration.json',config)
        try:
            initial=initial_checks(mm,qpclass,controller);write(folder/'initialization.json',initial)
            result=eng.run_case(mm,10,'reserved',controller,18.);trace_folder=folder/'results'/result['name']
            checked=audit_trace(trace_folder,mm,qpclass)
            events=json.loads((trace_folder/'step_records.json').read_text());metadata=sum(r['service']['metadata_resource'] for r in events)
            data=sum(len(r['service']['attempts']) for r in events)
            assert result['total_billed_resource']==metadata+data
            if network is SnapshotOnlyNetwork:
                assert metadata==180 and data==0 and result['total_billed_resource']==180
                assert all(r['service']['accepted_generation']==[-5,-5,-4] and not r['service']['arrivals'] for r in events)
            result.update(group=label,status='COMPLETED',actual_metadata_units=metadata,actual_data_transactions=data,
                          no_post_initial_packets=network is SnapshotOnlyNetwork,trace_audit=checked,configuration=config)
            write(trace_folder/'summary.json',result);outcomes.append(result)
        except Exception as e:
            failure=dict(group=label,status='FAILED',exception=repr(e),traceback=traceback.format_exc(),configuration=config)
            write(folder/'failure.json',failure);outcomes.append(failure)
        write(HERE/'targeted_summary.json',dict(cases=outcomes,original_P5_reference=reference,
                 original_ledger=charges,all_requested_cases_completed=len(outcomes)==4 and all(r['status']=='COMPLETED' for r in outcomes)))
        print(json.dumps({'group':label,'status':outcomes[-1]['status'],'bill':outcomes[-1].get('total_billed_resource'),'error':outcomes[-1].get('exception')}),flush=True)
    configure();assert all(r['status']=='COMPLETED' for r in outcomes)
if __name__=='__main__':main()
