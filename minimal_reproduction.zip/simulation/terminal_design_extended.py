"""Finite robust-predecessor terminal design, certified by Decimal intervals.

There is no closed-loop simulation here. Float facets are treated as exact fixed
coefficients in a directed-interval verification against the true exp lag model.
Every successor facet implies its preceding facet with a paid 1e-8 guard; the
last facet is checked over the full physical coordinate box. No LP optimum is
used as a proof or as an outward-rounded support bound.
"""
from decimal import Decimal as D, Context, ROUND_FLOOR, ROUND_CEILING, getcontext
import json
import math
import sys
import tempfile
import hashlib
from pathlib import Path
getcontext().prec = 80
import numpy as np
import scipy
from scipy.linalg import solve_discrete_lyapunov

ROOT = Path(__file__).resolve().parent

LO = Context(prec=80, rounding=ROUND_FLOOR)
HI = Context(prec=80, rounding=ROUND_CEILING)


class I:
    def __init__(self, x, y=None):
        self.lo = x if isinstance(x, D) else D(str(x))
        self.hi = self.lo if y is None else y

    @staticmethod
    def cast(x):
        return x if isinstance(x, I) else I(x)

    @staticmethod
    def fixed_float(x):
        return I(D.from_float(float(x)))

    def __add__(self, other):
        q = I.cast(other)
        return I(LO.add(self.lo, q.lo), HI.add(self.hi, q.hi))

    __radd__ = __add__

    def __neg__(self):
        return I(self.hi.copy_negate(), self.lo.copy_negate())

    def __sub__(self, other):
        return self + -I.cast(other)

    def __rsub__(self, other):
        return I.cast(other) + -self

    def __mul__(self, other):
        q = I.cast(other)
        pairs = [(self.lo, q.lo), (self.lo, q.hi), (self.hi, q.lo), (self.hi, q.hi)]
        return I(min(LO.multiply(a, b) for a, b in pairs),
                 max(HI.multiply(a, b) for a, b in pairs))

    __rmul__ = __mul__

    def __truediv__(self, other):
        q = I.cast(other)
        assert not q.lo <= 0 <= q.hi
        return self * I(LO.divide(D(1), q.hi), HI.divide(D(1), q.lo))

    def abs(self):
        if self.lo >= 0:
            return self
        if self.hi <= 0:
            return -self
        return I(D(0), max(self.lo.copy_negate(), self.hi))

    def exp(self):
        a, b = LO.exp(self.lo), HI.exp(self.hi)
        # Decimal exp is correctly rounded; a full decimal ulp is conservative.
        ea = D(1).scaleb(a.adjusted() - 79)
        eb = D(1).scaleb(b.adjusted() - 79)
        return I(LO.subtract(a, ea), HI.add(b, eb))


def dot(a, b):
    return sum((x*y for x, y in zip(a, b)), I(0))


def matmul(a, b):
    cols = list(zip(*b))
    return [[dot(row, col) for col in cols] for row in a]


def eye():
    return [[I(int(i == j)) for j in range(4)] for i in range(4)]


def mv(a, b):
    return [dot(row, b) for row in a]


def norm_upper(s, v):
    return max(dot(row, v).abs().hi for row in s)


def upper_sum(values):
    answer = D(0)
    for value in values:
        answer = HI.add(answer, value)
    return answer


def down_float(value):
    return math.nextafter(float(value), -math.inf)


def up_float(value):
    return math.nextafter(float(value), math.inf)


def as_float_array(value):
    if isinstance(value, I):
        return float(LO.divide(LO.add(value.lo, value.hi), D(2)))
    return np.array([as_float_array(x) for x in value])


def support_D(row, vb, ve, w, beta, delta):
    return beta*dot(row, vb).abs()+delta*dot(row, ve).abs()+sum(
        (row[a].abs()*w[a] for a in range(4)), I(0))


def support_box(row, box):
    return sum((row[a].abs()*box[a] for a in range(4)), I(0))


def implemented_terminal(zeta, crows, f, vb, ve, w, beta, delta, box):
    """Directly certify fixed binary64 facets, without assuming subset invariance."""
    znp, fnp = as_float_array(zeta), as_float_array(f)
    power=np.eye(4); allrows=[]
    for j in range(400):
        allrows.append(znp@power)
        power=power@fnp
    allrows=np.array(allrows)
    nr=len(zeta); rhs=np.empty((400,nr)); guard=D('1e-8')
    root_slacks=[]; transition_slacks=[]
    for l in range(nr):
        row0=[I.fixed_float(v) for v in allrows[0,l]]
        difference=[zeta[l][a]-row0[a] for a in range(4)]
        target=LO.subtract(crows[l].lo,support_box(difference,box).hi)
        rhs[0,l]=down_float(LO.subtract(target,guard))
        root_slacks.append((I(target)-I.fixed_float(rhs[0,l])).lo)
    for j in range(399):
        for l in range(nr):
            row=[I.fixed_float(v) for v in allrows[j,l]]
            rownext=[I.fixed_float(v) for v in allrows[j+1,l]]
            rowf=[dot(row,tuple(f[a][b] for a in range(4))) for b in range(4)]
            residual=[rowf[a]-rownext[a] for a in range(4)]
            uncertainty=support_D(row,vb,ve,w,beta,delta)
            reserr=support_box(residual,box)
            target=LO.subtract(LO.subtract(D.from_float(rhs[j,l]),uncertainty.hi),reserr.hi)
            rhs[j+1,l]=down_float(LO.subtract(target,guard))
            check=I.fixed_float(rhs[j,l])-I.fixed_float(rhs[j+1,l])-uncertainty-reserr
            assert check.lo>=guard
            transition_slacks.append(check.lo)
    tail_slacks=[]
    for l in range(nr):
        row=[I.fixed_float(v) for v in allrows[-1,l]]
        rowf=[dot(row,tuple(f[a][b] for a in range(4))) for b in range(4)]
        check=I.fixed_float(rhs[-1,l])-support_box(rowf,box)-support_D(row,vb,ve,w,beta,delta)
        assert check.lo>0
        tail_slacks.append(check.lo)
    assert np.min(rhs)>0
    cert={'initial_physical_containment_guard_lower':str(min(root_slacks)),
          'consecutive_facet_invariance_guard_lower':str(min(transition_slacks)),
          'last_facet_full_box_invariance_slack_lower':str(min(tail_slacks)),
          'all_terminal_rhs_positive':True,
          'zero_state_min_facet_rhs':float(np.min(rhs)),
          'facet_count':int(400*nr),
          'rounding_guard_each_step':str(guard),
          'verification':'Exact stored binary64 facet/rhs values enclosed by directed Decimal; true lag exp and all allowed box disturbances.'}
    return allrows.reshape(400*nr,4),rhs.reshape(400*nr),cert


def run(tau_text, k_text, qnorm, spre_text, sown_text, delta_text='.12', L_text='.25'):
    T, tau, h, omega, lam = map(I, ['.1', tau_text, '1.2', '.2', '.99'])
    alpha = (-T/tau).exp()
    c = tau*(1-alpha); bu=T-c; q=tau*bu; r=T*T/2-q
    a = [[I(1), -T, -(q+h*c), I(0)],
         [I(0), I(1), c, I(0)], [I(0), I(0), alpha, I(0)],
         [I(0), I(0), I(0), I(0)]]
    b = [-(r+h*bu), bu, 1-alpha, I(1)]
    k = [I.fixed_float(float(x)) for x in k_text]; L=I(L_text); beta=T*I(spre_text); delta=I(delta_text)
    f = [[a[i][j]+b[i]*k[j] for j in range(4)] for i in range(4)]
    wphysical = [(tau*r+h*q)*omega, q*omega, c*omega, I(0)]
    wnp=np.array([up_float(x.hi) if x.hi>0 else 0.0 for x in wphysical])
    w=[I.fixed_float(x) for x in wnp]
    assert all(w[i].lo>=wphysical[i].hi for i in range(4))
    vb=[I(int(i==0))+b[i]*L for i in range(4)]; ve=[x*L for x in b]
    dx=[I('.1'),I('.2'),I('.5'),I(1)/I('1.8')]
    s=[]; power=eye(); lpower=I(1)
    for j in range(qnorm):
        block=[[dx[i]*power[i][a]/lpower for a in range(4)] for i in range(4)]
        s.extend(block);s.extend([[-x for x in row] for row in block])
        power=matmul(power,f);lpower=lpower*lam
    power_norm=max(upper_sum((dx[i]*power[i][j]/dx[j]).abs().hi for j in range(4)) for i in range(4))
    assert power_norm < lpower.lo
    rows=[]
    for name, index, bound in [('tracking',0,I(10)),('speed',1,I(sown_text)-I('.2')),
                             ('acceleration',2,I(2)),('stored_command',3,I('1.8'))]:
        for sign in [1,-1]:
            hh=[I(0)]*4;hh[index]=I(sign);rows.append((name+'_'+str(sign),hh,I(0),bound))
    rows.append(('gap',list(map(I,[-1,'-1.2',0,0])),I(0),I(25)-T*(I(spre_text)+I(sown_text))))
    for sign in [1,-1]:
        rows.append(('command_'+str(sign),[I(0)]*4,I(sign),I('1.8')))
        rows.append(('rate_'+str(sign),list(map(I,[0,0,0,-sign])),I(sign),I('.3')))
    zeta=[[hh[j]+gg*k[j] for j in range(4)] for _,hh,gg,_ in rows]
    eta=[sum((z[j].abs()/dx[j] for j in range(4)),I(0)).hi for z in zeta]
    pb=[I(0)]*len(rows);pe=pb.copy();pw=pb.copy();power=eye()
    for j in range(400):
        zp=matmul(zeta,power)
        for l in range(len(rows)):
            pb[l]=pb[l]+dot(zp[l],vb).abs()
            pe[l]=pe[l]+dot(zp[l],ve).abs()
            pw[l]=pw[l]+sum((zp[l][a].abs()*w[a] for a in range(4)),I(0))
        power=matmul(power,f)
    sp=matmul(s,power)
    rb=HI.divide(norm_upper(sp,vb),D('.01'));re=HI.divide(norm_upper(sp,ve),D('.01'))
    rw=HI.divide(max(sum((rr[a].abs()*w[a] for a in range(4)),I(0)).hi for rr in sp),D('.01'))
    vv=list(map(I,[10,str(D(sown_text)-D('.2')),2,'1.8']))
    rj=max(sum((rr[a].abs()*vv[a] for a in range(4)),I(0)).hi for rr in sp)
    margins=[];closure=[];budget=[];a_coeff=[];b_coeff=[];support_upper=[]
    for l,(name,hh,gg,g) in enumerate(rows):
        direct=(gg*L).abs()
        aa=beta*(pb[l]+I(eta[l])*I(rb))+pw[l]+I(eta[l])*I(rw)+direct*beta
        bb=pe[l]+I(eta[l])*I(re)+direct
        margin=g-aa-bb*delta
        clo=margin-I(eta[l])*I(rj)
        margins.append((name,str(margin.lo)));closure.append((name,str(clo.lo)))
        assert margin.lo>0 and clo.lo>0
        if bb.hi>0:
            budget.append(LO.divide((g-aa).lo,bb.hi))
        else:
            assert (g-aa).lo>0
            budget.append(D('Infinity'))
        a_coeff.append(str(aa.hi));b_coeff.append(str(bb.hi))
        support_upper.append(str((aa+bb*delta).hi))
    crows=[g-(gg*L).abs()*(beta+delta) for _,hh,gg,g in rows]
    hf_matrix,hf_rhs,implementation_cert=implemented_terminal(zeta,crows,f,vb,ve,w,beta,delta,vv)
    anp,bnp,fnp,knp,snp=map(as_float_array,[a,b,f,k,s])
    dxnp=as_float_array(dx);Q=np.diag(dxnp*dxnp)
    Pf=solve_discrete_lyapunov(fnp.T,Q)
    assert np.max(np.abs(np.linalg.eigvals(fnp)))<.99
    data={'A':anp,'B':bnp,'E':np.array([1.,0.,0.,0.]),'F':fnp,'K':knp,
          'L':np.array(float(D(L_text))),'W_halfwidth':wnp,'S':snp,
          'H':as_float_array([rr[1] for rr in rows]),
          'G':as_float_array([rr[2] for rr in rows]),
          'g':as_float_array([rr[3] for rr in rows]),
          'Hf':hf_matrix,'hf':hf_rhs,'Q':Q,'Pf':Pf,'P_f':Pf,
          'tau':np.array(float(tau_text)),'h':np.array(1.2),
          'beta':np.array(float(beta.lo)),'delta':np.array(float(D(delta_text))),
          'Si':np.array(float(sown_text)),'Sprev':np.array(float(spre_text)),
          'U':np.array(1.8),'DU':np.array(.3),'sigma':np.array(.2),
          'ru':np.array(1/1.8**2),'rnu':np.array(25.),
          'alpha':np.array(as_float_array(alpha)),
          'c':np.array(as_float_array(c)),'bu':np.array(as_float_array(bu)),
          'q':np.array(as_float_array(q)),'r':np.array(as_float_array(r)),
          'physical_box':as_float_array(vv),'lambda':np.array(.99),
          'q_norm':np.array(qnorm),'terminal_length':np.array(400)}
    cert={'tau':tau_text,'interval_precision':80,'q_norm':qnorm,
            'K_roundtrip':[format(x,'.17g') for x in knp],
            'K_exact_binary_decimal':[str(D.from_float(float(x))) for x in knp],
            'spectral_radius_float':float(np.max(np.abs(np.linalg.eigvals(fnp)))),
            'L':float(D(L_text)),'beta':float(beta.lo),'delta':float(D(delta_text)),
            'operating_speed_previous':float(spre_text),'operating_speed_own':float(sown_text),
            'norm_power_upper':str(power_norm),'norm_power_rhs_lower':str(lpower.lo),
            'delta_max_certified_lower':str(min(budget)),
            'row_names':[rr[0] for rr in rows],
            'budget_base_upper':dict(zip((rr[0] for rr in rows),a_coeff)),
            'budget_slope_upper':dict(zip((rr[0] for rr in rows),b_coeff)),
            'infinite_row_support_upper':dict(zip((rr[0] for rr in rows),support_upper)),
            'terminal_margin_lower':dict(margins),'finite_closure_lower':dict(closure),
            'min_terminal_margin_lower':str(min(D(v) for _,v in margins)),
            'min_closure_lower':str(min(D(v) for _,v in closure)),
            'tail_coefficients_upper':list(map(str,[rb,re,rw])),
            'r_J_upper':str(rj),'implemented_polytope_certificate':implementation_cert,
            'zero_initial_state':'All hf strictly positive; invariance supplies the all-zero correction witness for every horizon and admissible cache.',
            'disturbance_box_contains_exact_integrated_bound':True}
    return data,cert


