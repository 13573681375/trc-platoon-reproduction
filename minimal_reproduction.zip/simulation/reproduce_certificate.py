"""Recompute original certificates and independently check every stored facet."""
from pathlib import Path
import sys,json,hashlib,tempfile
import numpy as np
import terminal_design as td
from decimal import Decimal as D
ROOT=Path(__file__).resolve().parents[1];HERE=ROOT/'simulation'
def independently_verify_stored(data,tau,k_text,spre,sown,delta='.12'):
    # Reconstruct exact decimal physical rows and true model independently of
    # the saved floating matrices; fixed K and facets are exact binary values.
    I=td.I;T=I('.1');ta=I(tau);h=I('1.2');L=I('.25');beta=T*I(spre);dd=I(delta)
    alpha=(-T/ta).exp();c=ta*(1-alpha);bu=T-c;q=ta*bu;r=T*T/2-q
    am=[[I(1),-T,-(q+h*c),I(0)],[I(0),I(1),c,I(0)],
        [I(0),I(0),alpha,I(0)],[I(0),I(0),I(0),I(0)]]
    b=[-(r+h*bu),bu,1-alpha,I(1)]
    kk=[I.fixed_float(float(v)) for v in k_text]
    F=[[am[a][j]+b[a]*kk[j] for j in range(4)] for a in range(4)]
    vb=[I(int(a==0))+b[a]*L for a in range(4)];ve=[b[a]*L for a in range(4)]
    W=[I.fixed_float(v) for v in data['W_halfwidth']]
    exact_w=[(ta*r+h*q)*I('.2'),q*I('.2'),c*I('.2'),I(0)]
    assert all(W[a].lo>=exact_w[a].hi for a in range(4))
    V=list(map(I,['10',str(D(sown)-D('.2')),'2','1.8']))
    H=[];G=[];g=[]
    for index,bound in enumerate(['10',str(D(sown)-D('.2')),'2','1.8']):
        for sign in (1,-1):
            row=[I(0) for _ in range(4)];row[index]=I(sign)
            H.append(row);G.append(I(0));g.append(I(bound))
    H.append(list(map(I,[-1,'-1.2',0,0])));G.append(I(0));g.append(I(25)-T*(I(spre)+I(sown)))
    for sign in (1,-1):
        H.append([I(0) for _ in range(4)]);G.append(I(sign));g.append(I('1.8'))
        H.append(list(map(I,[0,0,0,-sign])));G.append(I(sign));g.append(I('.3'))
    zeta=[[H[l][a]+G[l]*kk[a] for a in range(4)] for l in range(13)]
    gamma=[g[l]-(G[l]*L).abs()*(beta+dd) for l in range(13)]
    HH=data['Hf'].reshape(400,13,4);hh=data['hf'].reshape(400,13)
    assert np.array_equal(HH[0,:8],np.vstack([np.eye(4)[a]*sign for a in range(4) for sign in (1,-1)]))
    assert np.all(hh[0,:8]<=np.repeat([10,float(D(sown)-D('.2')),2,1.8],2))
    # The three lines of eq(35), independently applied to saved coefficients.
    mins=[None,None,None];failures=[0,0,0];counts=[0,0,0]
    for l in range(13):
        row=[I.fixed_float(v) for v in HH[0,l]]
        slack=gamma[l]-I.fixed_float(hh[0,l])-td.support_box([zeta[l][a]-row[a] for a in range(4)],V)
        mins[0]=slack.lo if mins[0] is None else min(mins[0],slack.lo);failures[0]+=slack.lo<0;counts[0]+=1
    for j in range(400):
        for l in range(13):
            row=[I.fixed_float(v) for v in HH[j,l]]
            rowF=[td.dot(row,[F[a][b_] for a in range(4)]) for b_ in range(4)]
            dist=td.support_D(row,vb,ve,W,beta,dd)
            if j<399:
                nextrow=[I.fixed_float(v) for v in HH[j+1,l]]
                lhs=I.fixed_float(hh[j+1,l])+dist+td.support_box([rowF[a]-nextrow[a] for a in range(4)],V)
                category=1
            else:lhs=dist+td.support_box(rowF,V);category=2
            slack=I.fixed_float(hh[j,l])-lhs
            mins[category]=slack.lo if mins[category] is None else min(mins[category],slack.lo)
            failures[category]+=slack.lo<0;counts[category]+=1
    assert sum(failures)==0 and np.min(data['hf'])>0
    return {'eq35_counts':counts,'eq35_failure_counts':failures,'eq35_min_certified_slacks':[str(v) for v in mins],
            'all_5200_facet_images_checked':True,'coordinate_box_containment':True,
            'disturbance_box_contains_true_integrated_bound':True,'origin_strictly_inside':True,
            'smallest_hf':float(data['hf'].min()),'precision_digits':80}
def main():
    old=json.loads((HERE/'terminal_certificate.json').read_text(encoding='utf-8'))
    records=[]
    for i,v in enumerate(old['vehicles'],1):
        k=v['K_roundtrip'];tau=v['tau'];spre=str(v['operating_speed_previous']);sown=str(v['operating_speed_own'])
        recomputed,cert=td.run(tau,k,v['q_norm'],spre,sown)
        with np.load(HERE/f'vehicle_{i}.npz',allow_pickle=False) as z: saved={name:z[name].copy() for name in z.files}
        differences={name:float(np.max(np.abs(saved[name]-value))) for name,value in recomputed.items()}
        assert all(value==0 for value in differences.values()),differences
        for key in ('norm_power_upper','norm_power_rhs_lower','delta_max_certified_lower','terminal_margin_lower','finite_closure_lower'):
            assert cert[key]==v[key],key
        independent=independently_verify_stored(saved,tau,k,spre,sown)
        records.append({'vehicle':i,'tau':tau,'all_saved_arrays_bitwise_equal':True,'max_array_difference':0.,
                        'independent_stored_check':independent,'recomputed_certificate':cert})
        print(json.dumps({'vehicle':i,'certificate_reproduced':True,'eq35_failure_counts':independent['eq35_failure_counts']}),flush=True)
    out={'date':'2026-10-14','CERTIFICATE_STATUS':'REPRODUCED','precision_digits':80,
         'source_sha256':hashlib.sha256((HERE/'terminal_design.py').read_bytes()).hexdigest(),
         'independent_verifier_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
         'all_checks_passed':True,'vehicles':records,'no_hardware_or_disturbance_change':True}
    (HERE/'certificate_reproduction.json').write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf-8')
if __name__=='__main__':main()
